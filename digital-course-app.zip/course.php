<?php
require_once 'common/config.php';

$page_title = 'Courses';
include 'common/header.php';

// Get filter parameters
$category = sanitize($_GET['category'] ?? '');
$sort = sanitize($_GET['sort'] ?? 'latest');
$search = sanitize($_GET['search'] ?? '');

// Build query
$where_clauses = ["status = 1"];

if (!empty($category)) {
    $where_clauses[] = "category = '$category'";
}

if (!empty($search)) {
    $where_clauses[] = "(title LIKE '%$search%' OR description LIKE '%$search%')";
}

$where_sql = implode(' AND ', $where_clauses);

// Sorting
$order_sql = match($sort) {
    'price_low' => 'price ASC',
    'price_high' => 'price DESC',
    'latest' => 'created_at DESC',
    default => 'created_at DESC'
};

$courses_query = "SELECT * FROM courses WHERE $where_sql ORDER BY $order_sql";
$courses_result = mysqli_query($conn, $courses_query);

// Get categories
$categories_query = "SELECT DISTINCT category FROM courses WHERE status = 1 AND category IS NOT NULL";
$categories_result = mysqli_query($conn, $categories_query);
?>

<!-- Search and Filters -->
<div class="bg-white p-4 shadow-sm">
    <div class="flex items-center space-x-2 mb-4">
        <!-- Category Filter -->
        <select id="categoryFilter" class="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
            <option value="">All Categories</option>
            <?php while ($cat = mysqli_fetch_assoc($categories_result)): ?>
                <option value="<?php echo htmlspecialchars($cat['category']); ?>" 
                    <?php echo $category === $cat['category'] ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($cat['category']); ?>
                </option>
            <?php endwhile; ?>
        </select>
        
        <!-- Sort Filter -->
        <select id="sortFilter" class="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
            <option value="latest" <?php echo $sort === 'latest' ? 'selected' : ''; ?>>Latest</option>
            <option value="price_low" <?php echo $sort === 'price_low' ? 'selected' : ''; ?>>Price: Low to High</option>
            <option value="price_high" <?php echo $sort === 'price_high' ? 'selected' : ''; ?>>Price: High to Low</option>
        </select>
    </div>
    
    <?php if (!empty($search)): ?>
        <div class="text-sm text-gray-600">
            Search results for: <strong><?php echo htmlspecialchars($search); ?></strong>
        </div>
    <?php endif; ?>
</div>

<!-- Course Grid -->
<div class="p-4">
    <div class="grid grid-cols-2 gap-4">
        <?php if (mysqli_num_rows($courses_result) > 0): ?>
            <?php while ($course = mysqli_fetch_assoc($courses_result)): ?>
                <a href="course_detail.php?id=<?php echo $course['id']; ?>" 
                    class="bg-white rounded-lg shadow-md overflow-hidden">
                    <div class="relative">
                        <img src="<?php echo htmlspecialchars($course['thumbnail']); ?>" 
                            alt="<?php echo htmlspecialchars($course['title']); ?>" 
                            class="w-full aspect-video object-cover">
                        <?php if ($course['mrp'] > $course['price']): ?>
                            <span class="absolute top-2 right-2 bg-green-500 text-white text-xs px-2 py-1 rounded">
                                <?php echo round((($course['mrp'] - $course['price']) / $course['mrp']) * 100); ?>% OFF
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="p-3">
                        <h3 class="font-semibold text-sm text-gray-800 mb-2 line-clamp-2">
                            <?php echo htmlspecialchars($course['title']); ?>
                        </h3>
                        <div class="flex items-center justify-between">
                            <div>
                                <span class="text-base font-bold text-blue-600">
                                    Rs <?php echo number_format($course['price'], 0); ?>
                                </span>
                                <?php if ($course['mrp'] > $course['price']): ?>
                                    <span class="text-xs text-gray-400 line-through ml-1">
                                        Rs <?php echo number_format($course['mrp'], 0); ?>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </a>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-span-2 text-center py-12 text-gray-500">
                <i class="fas fa-search text-5xl mb-4"></i>
                <p class="text-lg">No courses found</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
// Filter functionality
document.getElementById('categoryFilter').addEventListener('change', function() {
    updateFilters();
});

document.getElementById('sortFilter').addEventListener('change', function() {
    updateFilters();
});

function updateFilters() {
    const category = document.getElementById('categoryFilter').value;
    const sort = document.getElementById('sortFilter').value;
    const search = new URLSearchParams(window.location.search).get('search') || '';
    
    let url = 'course.php?';
    const params = [];
    
    if (category) params.push(`category=${encodeURIComponent(category)}`);
    if (sort) params.push(`sort=${sort}`);
    if (search) params.push(`search=${encodeURIComponent(search)}`);
    
    window.location.href = url + params.join('&');
}
</script>

<?php include 'common/bottom.php'; ?>
