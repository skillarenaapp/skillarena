<?php
require_once '../common/config.php';

header('Content-Type: application/json');

if (!isUserLoggedIn()) {
    jsonResponse(false, 'Please login to continue');
}

$course_id = intval($_POST['course_id'] ?? 0);
$user_id = $_SESSION['user_id'];

if ($course_id === 0) {
    jsonResponse(false, 'Invalid course');
}

// Fetch course
$course_query = "SELECT * FROM courses WHERE id = $course_id AND status = 1";
$course_result = mysqli_query($conn, $course_query);

if (mysqli_num_rows($course_result) === 0) {
    jsonResponse(false, 'Course not found');
}

$course = mysqli_fetch_assoc($course_result);

// Check if already purchased
$purchase_check = "SELECT id FROM purchases WHERE user_id = $user_id AND course_id = $course_id AND status = 'success'";
if (mysqli_num_rows(mysqli_query($conn, $purchase_check)) > 0) {
    jsonResponse(false, 'Course already purchased');
}

// Generate unique order ID
$order_id = 'ORD' . time() . rand(1000, 9999);

// Create pending purchase
$insert_purchase = "INSERT INTO purchases (user_id, course_id, order_id, amount, status) 
                    VALUES ($user_id, $course_id, '$order_id', {$course['price']}, 'pending')";

if (!mysqli_query($conn, $insert_purchase)) {
    jsonResponse(false, 'Failed to create order');
}

// Create pending payment
$insert_payment = "INSERT INTO payments (user_id, order_id, amount, status) 
                   VALUES ($user_id, '$order_id', {$course['price']}, 'pending')";
mysqli_query($conn, $insert_payment);

// In production, integrate with Cashfree API here
// For demo, return success
jsonResponse(true, 'Order created successfully', ['order_id' => $order_id]);
?>
