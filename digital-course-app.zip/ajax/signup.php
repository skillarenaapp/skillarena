<?php
require_once '../common/config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'Invalid request method');
}

$name = sanitize($_POST['name'] ?? '');
$phone = sanitize($_POST['phone'] ?? '');
$email = sanitize($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';

// Validate inputs
if (empty($name) || empty($phone) || empty($email) || empty($password)) {
    jsonResponse(false, 'Please fill in all fields');
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    jsonResponse(false, 'Invalid email format');
}

if (strlen($password) < 6) {
    jsonResponse(false, 'Password must be at least 6 characters');
}

// Check if email already exists
$check_query = "SELECT id FROM users WHERE email = '$email'";
$check_result = mysqli_query($conn, $check_query);

if (mysqli_num_rows($check_result) > 0) {
    jsonResponse(false, 'Email already registered');
}

// Hash password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Insert user
$insert_query = "INSERT INTO users (name, phone, email, password) VALUES ('$name', '$phone', '$email', '$hashed_password')";

if (mysqli_query($conn, $insert_query)) {
    $user_id = mysqli_insert_id($conn);
    
    // Set session
    $_SESSION['user_id'] = $user_id;
    $_SESSION['user_name'] = $name;
    $_SESSION['user_email'] = $email;
    
    jsonResponse(true, 'Account created successfully! Redirecting...');
} else {
    jsonResponse(false, 'Registration failed. Please try again.');
}
?>
