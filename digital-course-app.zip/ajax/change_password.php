<?php
require_once '../common/config.php';

header('Content-Type: application/json');

if (!isUserLoggedIn()) {
    jsonResponse(false, 'Please login to continue');
}

$user_id = $_SESSION['user_id'];
$current_password = $_POST['current_password'] ?? '';
$new_password = $_POST['new_password'] ?? '';

// Validate inputs
if (empty($current_password) || empty($new_password)) {
    jsonResponse(false, 'Please fill in all fields');
}

if (strlen($new_password) < 6) {
    jsonResponse(false, 'New password must be at least 6 characters');
}

// Get current password
$user_query = "SELECT password FROM users WHERE id = $user_id";
$user_result = mysqli_query($conn, $user_query);
$user = mysqli_fetch_assoc($user_result);

// Verify current password
if (!password_verify($current_password, $user['password'])) {
    jsonResponse(false, 'Current password is incorrect');
}

// Hash new password
$hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

// Update password
$update_query = "UPDATE users SET password = '$hashed_password' WHERE id = $user_id";

if (mysqli_query($conn, $update_query)) {
    jsonResponse(true, 'Password changed successfully');
} else {
    jsonResponse(false, 'Failed to change password');
}
?>
