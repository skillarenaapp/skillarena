<?php
require_once '../common/config.php';

header('Content-Type: application/json');

if (!isUserLoggedIn()) {
    jsonResponse(false, 'Please login to continue');
}

$user_id = $_SESSION['user_id'];
$name = sanitize($_POST['name'] ?? '');
$email = sanitize($_POST['email'] ?? '');
$phone = sanitize($_POST['phone'] ?? '');

// Validate inputs
if (empty($name) || empty($email) || empty($phone)) {
    jsonResponse(false, 'Please fill in all fields');
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    jsonResponse(false, 'Invalid email format');
}

// Check if email already exists for another user
$check_query = "SELECT id FROM users WHERE email = '$email' AND id != $user_id";
$check_result = mysqli_query($conn, $check_query);

if (mysqli_num_rows($check_result) > 0) {
    jsonResponse(false, 'Email already in use');
}

// Update user
$update_query = "UPDATE users SET name = '$name', email = '$email', phone = '$phone' WHERE id = $user_id";

if (mysqli_query($conn, $update_query)) {
    $_SESSION['user_name'] = $name;
    $_SESSION['user_email'] = $email;
    jsonResponse(true, 'Profile updated successfully');
} else {
    jsonResponse(false, 'Failed to update profile');
}
?>
