<?php
require_once '../common/config.php';

if (!isAdminLoggedIn()) {
    redirect('login.php');
}

// Fetch current settings
$settings_query = "SELECT * FROM settings";
$settings_result = mysqli_query($conn, $settings_query);
$settings = [];
while ($row = mysqli_fetch_assoc($settings_result)) {
    $settings[$row['setting_key']] = $row['setting_value'];
}

$page_title = 'Settings';
include 'common/header.php';
include 'common/sidebar.php';
?>

<div class="p-6">
    <h1 class="text-2xl font-bold text-gray-800 mb-6">Settings</h1>
    
    <div class="max-w-2xl">
        <!-- Site Settings -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-6">
            <h2 class="text-xl font-semibold mb-4">Site Information</h2>
            <form id="siteSettingsForm" class="space-y-4">
                <div>
                    <label class="block text-sm font-medium mb-2">Site Name</label>
                    <input type="text" name="site_name" 
                        value="<?php echo htmlspecialchars($settings['site_name'] ?? 'SkillzUp'); ?>" 
                        class="w-full border rounded-lg px-3 py-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-2">Support Email</label>
                    <input type="email" name="support_email" 
                        value="<?php echo htmlspecialchars($settings['support_email'] ?? ''); ?>" 
                        class="w-full border rounded-lg px-3 py-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-2">Support Phone</label>
                    <input type="text" name="support_phone" 
                        value="<?php echo htmlspecialchars($settings['support_phone'] ?? ''); ?>" 
                        class="w-full border rounded-lg px-3 py-2">
                </div>
                <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700">
                    Save Changes
                </button>
            </form>
        </div>
        
        <!-- Payment Gateway Settings -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-6">
            <h2 class="text-xl font-semibold mb-4">Cashfree Payment Gateway</h2>
            <form id="paymentSettingsForm" class="space-y-4">
                <div>
                    <label class="block text-sm font-medium mb-2">Cashfree App ID</label>
                    <input type="text" name="cashfree_app_id" 
                        value="<?php echo htmlspecialchars($settings['cashfree_app_id'] ?? ''); ?>" 
                        class="w-full border rounded-lg px-3 py-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-2">Cashfree Secret Key</label>
                    <input type="password" name="cashfree_secret_key" 
                        value="<?php echo htmlspecialchars($settings['cashfree_secret_key'] ?? ''); ?>" 
                        class="w-full border rounded-lg px-3 py-2">
                </div>
                <div class="flex items-center">
                    <input type="checkbox" name="cashfree_test_mode" id="cashfree_test_mode" 
                        <?php echo isset($settings['cashfree_test_mode']) && $settings['cashfree_test_mode'] == '1' ? 'checked' : ''; ?> 
                        class="mr-2">
                    <label for="cashfree_test_mode" class="text-sm">Test Mode (Sandbox)</label>
                </div>
                <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700">
                    Save Payment Settings
                </button>
            </form>
        </div>
        
        <!-- Admin Password Change -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-xl font-semibold mb-4">Change Admin Password</h2>
            <form id="passwordForm" class="space-y-4">
                <div>
                    <label class="block text-sm font-medium mb-2">Current Password</label>
                    <input type="password" name="current_password" required 
                        class="w-full border rounded-lg px-3 py-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-2">New Password</label>
                    <input type="password" name="new_password" required minlength="6"
                        class="w-full border rounded-lg px-3 py-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-2">Confirm New Password</label>
                    <input type="password" name="confirm_password" required minlength="6"
                        class="w-full border rounded-lg px-3 py-2">
                </div>
                <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                    Change Password
                </button>
            </form>
        </div>
    </div>
</div>

<script>
document.getElementById('siteSettingsForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    showLoading();
    
    fetch('ajax/save_settings.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        showToast(data.message, data.success ? 'success' : 'error');
    });
});

document.getElementById('paymentSettingsForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    formData.append('cashfree_test_mode', document.getElementById('cashfree_test_mode').checked ? '1' : '0');
    showLoading();
    
    fetch('ajax/save_settings.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        showToast(data.message, data.success ? 'success' : 'error');
    });
});

document.getElementById('passwordForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    
    if (formData.get('new_password') !== formData.get('confirm_password')) {
        showToast('Passwords do not match', 'error');
        return;
    }
    
    showLoading();
    
    fetch('ajax/change_admin_password.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        showToast(data.message, data.success ? 'success' : 'error');
        if (data.success) {
            this.reset();
        }
    });
});
</script>
