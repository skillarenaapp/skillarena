<?php
require_once '../common/config.php';

if (!isAdminLoggedIn()) {
    redirect('login.php');
}

$users_query = "SELECT u.*, COUNT(DISTINCT p.id) as purchase_count 
                FROM users u 
                LEFT JOIN purchases p ON u.id = p.user_id AND p.status = 'success' 
                GROUP BY u.id 
                ORDER BY u.created_at DESC";
$users = mysqli_query($conn, $users_query);

$page_title = 'Users Management';
include 'common/header.php';
include 'common/sidebar.php';
?>

<div class="p-6">
    <h1 class="text-2xl font-bold text-gray-800 mb-6">Users Management</h1>
    
    <div class="bg-white rounded-lg shadow-md overflow-x-auto">
        <table class="w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="text-left py-3 px-4">ID</th>
                    <th class="text-left py-3 px-4">Name</th>
                    <th class="text-left py-3 px-4">Email</th>
                    <th class="text-left py-3 px-4">Phone</th>
                    <th class="text-left py-3 px-4">Purchases</th>
                    <th class="text-left py-3 px-4">Joined</th>
                    <th class="text-left py-3 px-4">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($user = mysqli_fetch_assoc($users)): ?>
                    <tr class="border-b hover:bg-gray-50">
                        <td class="py-3 px-4"><?php echo $user['id']; ?></td>
                        <td class="py-3 px-4 font-medium"><?php echo htmlspecialchars($user['name']); ?></td>
                        <td class="py-3 px-4"><?php echo htmlspecialchars($user['email']); ?></td>
                        <td class="py-3 px-4"><?php echo htmlspecialchars($user['phone']); ?></td>
                        <td class="py-3 px-4">
                            <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded text-sm">
                                <?php echo $user['purchase_count']; ?> courses
                            </span>
                        </td>
                        <td class="py-3 px-4 text-sm"><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                        <td class="py-3 px-4">
                            <button onclick="viewUserDetails(<?php echo $user['id']; ?>)" 
                                class="text-blue-600 hover:text-blue-800">
                                <i class="fas fa-eye"></i>
                            </button>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<div id="userModal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50">
    <div class="bg-white rounded-lg p-6 w-full max-w-2xl m-4 max-h-screen overflow-y-auto">
        <h2 class="text-xl font-bold mb-4">User Details</h2>
        <div id="userDetails"></div>
        <button onclick="closeModal()" class="mt-4 w-full bg-gray-300 py-2 rounded-lg">Close</button>
    </div>
</div>

<script>
function viewUserDetails(userId) {
    showLoading();
    fetch(`ajax/user_details.php?id=${userId}`)
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            document.getElementById('userDetails').innerHTML = data.html;
            document.getElementById('userModal').classList.remove('hidden');
            document.getElementById('userModal').classList.add('flex');
        }
    });
}

function closeModal() {
    document.getElementById('userModal').classList.add('hidden');
}
</script>
