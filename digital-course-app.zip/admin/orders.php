<?php
require_once '../common/config.php';

if (!isAdminLoggedIn()) {
    redirect('login.php');
}

$orders_query = "SELECT p.*, u.name as user_name, u.email as user_email, c.title as course_title 
                 FROM purchases p 
                 INNER JOIN users u ON p.user_id = u.id 
                 INNER JOIN courses c ON p.course_id = c.id 
                 ORDER BY p.created_at DESC";
$orders = mysqli_query($conn, $orders_query);

$page_title = 'Orders Management';
include 'common/header.php';
include 'common/sidebar.php';
?>

<div class="p-6">
    <h1 class="text-2xl font-bold text-gray-800 mb-6">Orders Management</h1>
    
    <div class="bg-white rounded-lg shadow-md overflow-x-auto">
        <table class="w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="text-left py-3 px-4">Order ID</th>
                    <th class="text-left py-3 px-4">User</th>
                    <th class="text-left py-3 px-4">Course</th>
                    <th class="text-left py-3 px-4">Amount</th>
                    <th class="text-left py-3 px-4">Status</th>
                    <th class="text-left py-3 px-4">Date</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($order = mysqli_fetch_assoc($orders)): ?>
                    <tr class="border-b hover:bg-gray-50">
                        <td class="py-3 px-4 font-mono text-sm"><?php echo htmlspecialchars($order['order_id']); ?></td>
                        <td class="py-3 px-4">
                            <p class="font-medium"><?php echo htmlspecialchars($order['user_name']); ?></p>
                            <p class="text-sm text-gray-500"><?php echo htmlspecialchars($order['user_email']); ?></p>
                        </td>
                        <td class="py-3 px-4"><?php echo htmlspecialchars($order['course_title']); ?></td>
                        <td class="py-3 px-4 font-semibold">Rs <?php echo number_format($order['amount'], 2); ?></td>
                        <td class="py-3 px-4">
                            <span class="px-2 py-1 rounded-full text-xs <?php 
                                echo $order['status'] === 'success' ? 'bg-green-100 text-green-700' : 
                                     ($order['status'] === 'failed' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'); 
                            ?>">
                                <?php echo ucfirst($order['status']); ?>
                            </span>
                        </td>
                        <td class="py-3 px-4 text-sm"><?php echo date('M d, Y H:i', strtotime($order['created_at'])); ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
