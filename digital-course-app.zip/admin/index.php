<?php
require_once '../common/config.php';

if (!isAdminLoggedIn()) {
    redirect('login.php');
}

// Fetch statistics
$total_users = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM users"))['count'];
$total_courses = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM courses WHERE status = 1"))['count'];
$total_purchases = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM purchases WHERE status = 'success'"))['count'];
$total_revenue = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(amount) as total FROM payments WHERE status = 'success'"))['total'] ?? 0;

// Recent orders
$recent_orders_query = "SELECT p.*, u.name as user_name, c.title as course_title 
                        FROM purchases p 
                        INNER JOIN users u ON p.user_id = u.id 
                        INNER JOIN courses c ON p.course_id = c.id 
                        ORDER BY p.created_at DESC LIMIT 5";
$recent_orders = mysqli_query($conn, $recent_orders_query);

$page_title = 'Dashboard';
include 'common/header.php';
include 'common/sidebar.php';
?>

<div class="p-6">
    <h1 class="text-2xl font-bold text-gray-800 mb-6">Dashboard</h1>
    
    <!-- Stats Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-gray-600 text-sm font-medium">Total Users</h3>
                <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                    <i class="fas fa-users text-blue-600 text-xl"></i>
                </div>
            </div>
            <p class="text-3xl font-bold text-gray-800"><?php echo number_format($total_users); ?></p>
        </div>
        
        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-gray-600 text-sm font-medium">Active Courses</h3>
                <div class="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                    <i class="fas fa-book text-green-600 text-xl"></i>
                </div>
            </div>
            <p class="text-3xl font-bold text-gray-800"><?php echo number_format($total_courses); ?></p>
        </div>
        
        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-gray-600 text-sm font-medium">Total Sales</h3>
                <div class="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                    <i class="fas fa-shopping-cart text-purple-600 text-xl"></i>
                </div>
            </div>
            <p class="text-3xl font-bold text-gray-800"><?php echo number_format($total_purchases); ?></p>
        </div>
        
        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-gray-600 text-sm font-medium">Revenue</h3>
                <div class="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center">
                    <i class="fas fa-rupee-sign text-yellow-600 text-xl"></i>
                </div>
            </div>
            <p class="text-3xl font-bold text-gray-800">Rs <?php echo number_format($total_revenue, 2); ?></p>
        </div>
    </div>
    
    <!-- Quick Actions -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <a href="course.php?action=add" 
            class="bg-blue-600 text-white rounded-lg shadow-md p-6 hover:bg-blue-700 transition flex items-center justify-between">
            <div>
                <h3 class="text-lg font-semibold mb-1">Add New Course</h3>
                <p class="text-blue-100 text-sm">Create and publish a new course</p>
            </div>
            <i class="fas fa-plus-circle text-3xl"></i>
        </a>
        
        <a href="banner.php?action=add" 
            class="bg-green-600 text-white rounded-lg shadow-md p-6 hover:bg-green-700 transition flex items-center justify-between">
            <div>
                <h3 class="text-lg font-semibold mb-1">Add New Banner</h3>
                <p class="text-green-100 text-sm">Upload a promotional banner</p>
            </div>
            <i class="fas fa-image text-3xl"></i>
        </a>
    </div>
    
    <!-- Recent Orders -->
    <div class="bg-white rounded-lg shadow-md p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Recent Orders</h2>
        
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead>
                    <tr class="border-b">
                        <th class="text-left py-3 px-4 text-gray-600 font-semibold">Order ID</th>
                        <th class="text-left py-3 px-4 text-gray-600 font-semibold">User</th>
                        <th class="text-left py-3 px-4 text-gray-600 font-semibold">Course</th>
                        <th class="text-left py-3 px-4 text-gray-600 font-semibold">Amount</th>
                        <th class="text-left py-3 px-4 text-gray-600 font-semibold">Status</th>
                        <th class="text-left py-3 px-4 text-gray-600 font-semibold">Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($order = mysqli_fetch_assoc($recent_orders)): ?>
                        <tr class="border-b hover:bg-gray-50">
                            <td class="py-3 px-4 font-mono text-sm"><?php echo htmlspecialchars($order['order_id']); ?></td>
                            <td class="py-3 px-4"><?php echo htmlspecialchars($order['user_name']); ?></td>
                            <td class="py-3 px-4"><?php echo htmlspecialchars($order['course_title']); ?></td>
                            <td class="py-3 px-4 font-semibold">Rs <?php echo number_format($order['amount'], 2); ?></td>
                            <td class="py-3 px-4">
                                <span class="px-2 py-1 rounded-full text-xs <?php echo $order['status'] === 'success' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'; ?>">
                                    <?php echo ucfirst($order['status']); ?>
                                </span>
                            </td>
                            <td class="py-3 px-4 text-sm"><?php echo date('M d, Y', strtotime($order['created_at'])); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'common/sidebar.php'; ?>
