<?php
require_once '../common/config.php';

if (!isAdminLoggedIn()) {
    redirect('login.php');
}

// Fetch all courses
$courses_query = "SELECT * FROM courses ORDER BY created_at DESC";
$courses = mysqli_query($conn, $courses_query);

$page_title = 'Course Management';
include 'common/header.php';
include 'common/sidebar.php';
?>

<div class="p-6">
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-2xl font-bold text-gray-800">Course Management</h1>
        <button onclick="openAddModal()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
            <i class="fas fa-plus mr-2"></i> Add Course
        </button>
    </div>
    
    <div class="bg-white rounded-lg shadow-md overflow-x-auto">
        <table class="w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="text-left py-3 px-4">Course</th>
                    <th class="text-left py-3 px-4">Category</th>
                    <th class="text-left py-3 px-4">MRP</th>
                    <th class="text-left py-3 px-4">Price</th>
                    <th class="text-left py-3 px-4">Status</th>
                    <th class="text-left py-3 px-4">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($course = mysqli_fetch_assoc($courses)): ?>
                    <tr class="border-b hover:bg-gray-50">
                        <td class="py-3 px-4">
                            <div class="flex items-center space-x-3">
                                <img src="<?php echo htmlspecialchars($course['thumbnail']); ?>" 
                                    class="w-16 h-10 object-cover rounded">
                                <span class="font-medium"><?php echo htmlspecialchars($course['title']); ?></span>
                            </div>
                        </td>
                        <td class="py-3 px-4"><?php echo htmlspecialchars($course['category'] ?? '-'); ?></td>
                        <td class="py-3 px-4">Rs <?php echo number_format($course['mrp'], 2); ?></td>
                        <td class="py-3 px-4">Rs <?php echo number_format($course['price'], 2); ?></td>
                        <td class="py-3 px-4">
                            <span class="px-2 py-1 rounded text-xs <?php echo $course['status'] ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'; ?>">
                                <?php echo $course['status'] ? 'Active' : 'Inactive'; ?>
                            </span>
                        </td>
                        <td class="py-3 px-4">
                            <div class="flex space-x-2">
                                <a href="chapter.php?course_id=<?php echo $course['id']; ?>" 
                                    class="text-blue-600 hover:text-blue-800" title="Manage Chapters">
                                    <i class="fas fa-list"></i>
                                </a>
                                <button onclick="editCourse(<?php echo $course['id']; ?>)" 
                                    class="text-green-600 hover:text-green-800">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button onclick="deleteCourse(<?php echo $course['id']; ?>)" 
                                    class="text-red-600 hover:text-red-800">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Add/Edit Course Modal -->
<div id="courseModal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50 overflow-y-auto">
    <div class="bg-white rounded-lg p-6 w-full max-w-2xl m-4">
        <h2 id="modalTitle" class="text-xl font-bold mb-4">Add New Course</h2>
        <form id="courseForm" enctype="multipart/form-data">
            <input type="hidden" name="course_id" id="course_id">
            <div class="space-y-4">
                <div>
                    <label class="block text-sm font-medium mb-2">Course Title</label>
                    <input type="text" name="title" id="title" required 
                        class="w-full border rounded-lg px-3 py-2">
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium mb-2">Category</label>
                        <input type="text" name="category" id="category" 
                            class="w-full border rounded-lg px-3 py-2">
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-2">Thumbnail</label>
                        <input type="file" name="thumbnail" id="thumbnail" accept="image/*" 
                            class="w-full border rounded-lg px-3 py-2">
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium mb-2">MRP</label>
                        <input type="number" name="mrp" id="mrp" step="0.01" required 
                            class="w-full border rounded-lg px-3 py-2">
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-2">Sale Price</label>
                        <input type="number" name="price" id="price" step="0.01" required 
                            class="w-full border rounded-lg px-3 py-2">
                    </div>
                </div>
                <div>
                    <label class="block text-sm font-medium mb-2">Description</label>
                    <textarea name="description" id="description" rows="4" required 
                        class="w-full border rounded-lg px-3 py-2"></textarea>
                </div>
                <div class="flex space-x-2">
                    <button type="submit" class="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700">
                        Save Course
                    </button>
                    <button type="button" onclick="closeModal()" 
                        class="flex-1 bg-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-400">
                        Cancel
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
function openAddModal() {
    document.getElementById('modalTitle').textContent = 'Add New Course';
    document.getElementById('courseForm').reset();
    document.getElementById('course_id').value = '';
    document.getElementById('courseModal').classList.remove('hidden');
    document.getElementById('courseModal').classList.add('flex');
}

function closeModal() {
    document.getElementById('courseModal').classList.add('hidden');
}

document.getElementById('courseForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    showLoading();
    
    fetch('ajax/course_save.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showToast(data.message, 'success');
            setTimeout(() => location.reload(), 1000);
        } else {
            showToast(data.message, 'error');
        }
    });
});

function deleteCourse(id) {
    if (confirm('Delete this course? All chapters and videos will be deleted.')) {
        fetch('ajax/course_delete.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: `id=${id}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showToast(data.message, 'success');
                setTimeout(() => location.reload(), 1000);
            }
        });
    }
}
</script>
