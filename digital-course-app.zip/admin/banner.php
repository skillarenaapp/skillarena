<?php
require_once '../common/config.php';

if (!isAdminLoggedIn()) {
    redirect('login.php');
}

// Fetch all banners
$banners_query = "SELECT * FROM banners ORDER BY id DESC";
$banners = mysqli_query($conn, $banners_query);

$page_title = 'Banner Management';
include 'common/header.php';
include 'common/sidebar.php';
?>

<div class="p-6">
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-2xl font-bold text-gray-800">Banner Management</h1>
        <button onclick="openAddModal()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
            <i class="fas fa-plus mr-2"></i> Add Banner
        </button>
    </div>
    
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php while ($banner = mysqli_fetch_assoc($banners)): ?>
            <div class="bg-white rounded-lg shadow-md overflow-hidden">
                <img src="<?php echo htmlspecialchars($banner['image']); ?>" 
                    class="w-full aspect-video object-cover">
                <div class="p-4">
                    <p class="text-sm text-gray-600 mb-2">
                        <?php echo $banner['link'] ? htmlspecialchars($banner['link']) : 'No link'; ?>
                    </p>
                    <div class="flex items-center justify-between">
                        <span class="px-2 py-1 rounded text-xs <?php echo $banner['status'] ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'; ?>">
                            <?php echo $banner['status'] ? 'Active' : 'Inactive'; ?>
                        </span>
                        <div class="space-x-2">
                            <button onclick="toggleStatus(<?php echo $banner['id']; ?>, <?php echo $banner['status']; ?>)" 
                                class="text-blue-600 hover:text-blue-800">
                                <i class="fas fa-toggle-<?php echo $banner['status'] ? 'on' : 'off'; ?>"></i>
                            </button>
                            <button onclick="deleteBanner(<?php echo $banner['id']; ?>)" 
                                class="text-red-600 hover:text-red-800">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<!-- Add Banner Modal -->
<div id="addModal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50">
    <div class="bg-white rounded-lg p-6 w-full max-w-md m-4">
        <h2 class="text-xl font-bold mb-4">Add New Banner</h2>
        <form id="addBannerForm" enctype="multipart/form-data">
            <div class="space-y-4">
                <div>
                    <label class="block text-sm font-medium mb-2">Banner Image (16:9 ratio)</label>
                    <input type="file" name="image" accept="image/*" required 
                        class="w-full border rounded-lg px-3 py-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-2">Link (Optional)</label>
                    <input type="url" name="link" 
                        class="w-full border rounded-lg px-3 py-2" placeholder="https://example.com">
                </div>
                <div class="flex space-x-2">
                    <button type="submit" class="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700">
                        Upload
                    </button>
                    <button type="button" onclick="closeAddModal()" 
                        class="flex-1 bg-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-400">
                        Cancel
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
function openAddModal() {
    document.getElementById('addModal').classList.remove('hidden');
    document.getElementById('addModal').classList.add('flex');
}

function closeAddModal() {
    document.getElementById('addModal').classList.add('hidden');
    document.getElementById('addModal').classList.remove('flex');
}

document.getElementById('addBannerForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    showLoading();
    
    fetch('ajax/banner_add.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showToast(data.message, 'success');
            setTimeout(() => location.reload(), 1000);
        } else {
            showToast(data.message, 'error');
        }
    });
});

function toggleStatus(id, currentStatus) {
    if (confirm('Change banner status?')) {
        fetch('ajax/banner_toggle.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: `id=${id}&status=${currentStatus ? 0 : 1}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showToast(data.message, 'success');
                setTimeout(() => location.reload(), 1000);
            }
        });
    }
}

function deleteBanner(id) {
    if (confirm('Delete this banner?')) {
        fetch('ajax/banner_delete.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: `id=${id}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showToast(data.message, 'success');
                setTimeout(() => location.reload(), 1000);
            }
        });
    }
}
</script>
