<!-- Admin Sidebar -->
<aside id="sidebar" class="sidebar fixed top-0 left-0 h-full w-64 bg-gray-900 text-white z-50 overflow-y-auto">
    <div class="p-4">
        <div class="mb-8 text-center border-b border-gray-700 pb-4">
            <div class="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-2">
                A
            </div>
            <h3 class="font-semibold">Admin Panel</h3>
        </div>
        
        <nav class="space-y-1">
            <a href="index.php" class="flex items-center space-x-3 px-4 py-3 rounded-lg <?php echo $current_page == 'index' ? 'bg-blue-600' : 'hover:bg-gray-800'; ?>">
                <i class="fas fa-chart-line w-5"></i>
                <span>Dashboard</span>
            </a>
            
            <a href="banner.php" class="flex items-center space-x-3 px-4 py-3 rounded-lg <?php echo $current_page == 'banner' ? 'bg-blue-600' : 'hover:bg-gray-800'; ?>">
                <i class="fas fa-images w-5"></i>
                <span>Banners</span>
            </a>
            
            <a href="course.php" class="flex items-center space-x-3 px-4 py-3 rounded-lg <?php echo $current_page == 'course' ? 'bg-blue-600' : 'hover:bg-gray-800'; ?>">
                <i class="fas fa-book w-5"></i>
                <span>Courses</span>
            </a>
            
            <a href="users.php" class="flex items-center space-x-3 px-4 py-3 rounded-lg <?php echo $current_page == 'users' ? 'bg-blue-600' : 'hover:bg-gray-800'; ?>">
                <i class="fas fa-users w-5"></i>
                <span>Users</span>
            </a>
            
            <a href="orders.php" class="flex items-center space-x-3 px-4 py-3 rounded-lg <?php echo $current_page == 'orders' ? 'bg-blue-600' : 'hover:bg-gray-800'; ?>">
                <i class="fas fa-shopping-cart w-5"></i>
                <span>Orders</span>
            </a>
            
            <a href="payments.php" class="flex items-center space-x-3 px-4 py-3 rounded-lg <?php echo $current_page == 'payments' ? 'bg-blue-600' : 'hover:bg-gray-800'; ?>">
                <i class="fas fa-credit-card w-5"></i>
                <span>Payments</span>
            </a>
            
            <a href="settings.php" class="flex items-center space-x-3 px-4 py-3 rounded-lg <?php echo $current_page == 'settings' ? 'bg-blue-600' : 'hover:bg-gray-800'; ?>">
                <i class="fas fa-cog w-5"></i>
                <span>Settings</span>
            </a>
            
            <hr class="my-2 border-gray-700">
            
            <a href="../index.php" target="_blank" class="flex items-center space-x-3 px-4 py-3 rounded-lg hover:bg-gray-800">
                <i class="fas fa-external-link-alt w-5"></i>
                <span>View Site</span>
            </a>
            
            <a href="logout.php" class="flex items-center space-x-3 px-4 py-3 rounded-lg hover:bg-red-600">
                <i class="fas fa-sign-out-alt w-5"></i>
                <span>Logout</span>
            </a>
        </nav>
    </div>
</aside>

<script>
const menuBtn = document.getElementById('menuBtn');
const sidebar = document.getElementById('sidebar');
const sidebarOverlay = document.getElementById('sidebarOverlay');

menuBtn?.addEventListener('click', () => {
    sidebar.classList.add('active');
    sidebarOverlay.classList.remove('hidden');
});

sidebarOverlay?.addEventListener('click', () => {
    sidebar.classList.remove('active');
    sidebarOverlay.classList.add('hidden');
});

function showLoading() {
    const loader = document.createElement('div');
    loader.id = 'globalLoader';
    loader.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
    loader.innerHTML = '<div class="bg-white rounded-lg p-6"><i class="fas fa-spinner fa-spin text-4xl text-blue-600"></i></div>';
    document.body.appendChild(loader);
}

function hideLoading() {
    document.getElementById('globalLoader')?.remove();
}

function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    const colors = {
        success: 'bg-green-500',
        error: 'bg-red-500',
        warning: 'bg-yellow-500',
        info: 'bg-blue-500'
    };
    toast.className = `fixed top-20 right-4 p-4 rounded-lg shadow-lg z-50 ${colors[type]} text-white`;
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transition = 'opacity 0.3s';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}
</script>

</body>
</html>
