<?php
if (!isset($_SESSION)) {
    session_start();
}

$page_title = isset($page_title) ? $page_title : 'Admin Panel';
$current_page = basename($_SERVER['PHP_SELF'], '.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo htmlspecialchars($page_title); ?> - SkillzUp Admin</title>
    
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <style>
        .sidebar {
            transform: translateX(-100%);
            transition: transform 0.3s ease-in-out;
        }
        .sidebar.active {
            transform: translateX(0);
        }
        
        @media (min-width: 1024px) {
            .sidebar {
                transform: translateX(0);
            }
        }
    </style>
</head>
<body class="bg-gray-100">
    
    <!-- Top Header -->
    <header class="bg-white shadow-sm fixed top-0 left-0 right-0 z-40 lg:left-64">
        <div class="flex items-center justify-between px-4 py-3">
            <button id="menuBtn" class="lg:hidden text-gray-700 text-xl">
                <i class="fas fa-bars"></i>
            </button>
            <h1 class="text-xl font-bold text-blue-600">SkillzUp Admin</h1>
            <a href="settings.php" class="text-gray-700 text-xl">
                <i class="fas fa-cog"></i>
            </a>
        </div>
    </header>
    
    <div id="sidebarOverlay" class="fixed inset-0 bg-black bg-opacity-50 z-40 hidden lg:hidden"></div>
    
    <main class="pt-16 lg:ml-64 min-h-screen">
