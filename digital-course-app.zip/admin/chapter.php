<?php
require_once '../common/config.php';

if (!isAdminLoggedIn()) {
    redirect('login.php');
}

$course_id = intval($_GET['course_id'] ?? 0);

if ($course_id === 0) {
    redirect('course.php');
}

$course = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM courses WHERE id = $course_id"));
$chapters = mysqli_query($conn, "SELECT * FROM chapters WHERE course_id = $course_id ORDER BY sort_order ASC");

$page_title = 'Chapter Management';
include 'common/header.php';
include 'common/sidebar.php';
?>

<div class="p-6">
    <div class="mb-6">
        <a href="course.php" class="text-blue-600 hover:underline mb-2 inline-block">
            <i class="fas fa-arrow-left mr-2"></i> Back to Courses
        </a>
        <h1 class="text-2xl font-bold text-gray-800"><?php echo htmlspecialchars($course['title']); ?></h1>
        <p class="text-gray-600">Manage chapters and videos</p>
    </div>
    
    <button onclick="openAddModal()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 mb-4">
        <i class="fas fa-plus mr-2"></i> Add Chapter
    </button>
    
    <div class="space-y-4">
        <?php while ($chapter = mysqli_fetch_assoc($chapters)): ?>
            <?php
            $chapter_id = $chapter['id'];
            $videos_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM videos WHERE chapter_id = $chapter_id"))['count'];
            ?>
            <div class="bg-white rounded-lg shadow-md p-4">
                <div class="flex items-center justify-between">
                    <div class="flex-1">
                        <h3 class="font-semibold text-gray-800"><?php echo htmlspecialchars($chapter['title']); ?></h3>
                        <p class="text-sm text-gray-500"><?php echo $videos_count; ?> videos</p>
                    </div>
                    <div class="flex space-x-2">
                        <a href="video.php?chapter_id=<?php echo $chapter_id; ?>" 
                            class="bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700">
                            <i class="fas fa-video mr-1"></i> Videos
                        </a>
                        <button onclick="deleteChapter(<?php echo $chapter_id; ?>)" 
                            class="text-red-600 hover:text-red-800">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<div id="addModal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50">
    <div class="bg-white rounded-lg p-6 w-full max-w-md m-4">
        <h2 class="text-xl font-bold mb-4">Add New Chapter</h2>
        <form id="chapterForm">
            <input type="hidden" name="course_id" value="<?php echo $course_id; ?>">
            <div class="space-y-4">
                <div>
                    <label class="block text-sm font-medium mb-2">Chapter Title</label>
                    <input type="text" name="title" required class="w-full border rounded-lg px-3 py-2">
                </div>
                <div class="flex space-x-2">
                    <button type="submit" class="flex-1 bg-blue-600 text-white py-2 rounded-lg">Save</button>
                    <button type="button" onclick="closeModal()" class="flex-1 bg-gray-300 py-2 rounded-lg">Cancel</button>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
function openAddModal() {
    document.getElementById('addModal').classList.remove('hidden');
    document.getElementById('addModal').classList.add('flex');
}

function closeModal() {
    document.getElementById('addModal').classList.add('hidden');
}

document.getElementById('chapterForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    showLoading();
    
    fetch('ajax/chapter_add.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showToast(data.message, 'success');
            setTimeout(() => location.reload(), 1000);
        } else {
            showToast(data.message, 'error');
        }
    });
});

function deleteChapter(id) {
    if (confirm('Delete this chapter and all its videos?')) {
        fetch('ajax/chapter_delete.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: `id=${id}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showToast(data.message, 'success');
                setTimeout(() => location.reload(), 1000);
            }
        });
    }
}
</script>
