<?php
require_once '../common/config.php';

if (!isAdminLoggedIn()) {
    redirect('login.php');
}

$chapter_id = intval($_GET['chapter_id'] ?? 0);

if ($chapter_id === 0) {
    redirect('course.php');
}

$chapter = mysqli_fetch_assoc(mysqli_query($conn, "SELECT c.*, co.title as course_title, co.id as course_id FROM chapters c INNER JOIN courses co ON c.course_id = co.id WHERE c.id = $chapter_id"));
$videos = mysqli_query($conn, "SELECT * FROM videos WHERE chapter_id = $chapter_id ORDER BY sort_order ASC");

$page_title = 'Video Management';
include 'common/header.php';
include 'common/sidebar.php';
?>

<div class="p-6">
    <div class="mb-6">
        <a href="chapter.php?course_id=<?php echo $chapter['course_id']; ?>" class="text-blue-600 hover:underline mb-2 inline-block">
            <i class="fas fa-arrow-left mr-2"></i> Back to Chapters
        </a>
        <h1 class="text-2xl font-bold text-gray-800"><?php echo htmlspecialchars($chapter['title']); ?></h1>
        <p class="text-gray-600"><?php echo htmlspecialchars($chapter['course_title']); ?></p>
    </div>
    
    <button onclick="openAddModal()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 mb-4">
        <i class="fas fa-plus mr-2"></i> Add Video
    </button>
    
    <div class="space-y-4">
        <?php while ($video = mysqli_fetch_assoc($videos)): ?>
            <div class="bg-white rounded-lg shadow-md p-4">
                <div class="flex items-center justify-between">
                    <div class="flex-1">
                        <h3 class="font-semibold text-gray-800"><?php echo htmlspecialchars($video['title']); ?></h3>
                        <p class="text-sm text-gray-500"><?php echo htmlspecialchars($video['duration'] ?? 'No duration'); ?></p>
                    </div>
                    <button onclick="deleteVideo(<?php echo $video['id']; ?>)" 
                        class="text-red-600 hover:text-red-800">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<div id="addModal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50">
    <div class="bg-white rounded-lg p-6 w-full max-w-md m-4">
        <h2 class="text-xl font-bold mb-4">Add New Video</h2>
        <form id="videoForm" enctype="multipart/form-data">
            <input type="hidden" name="chapter_id" value="<?php echo $chapter_id; ?>">
            <div class="space-y-4">
                <div>
                    <label class="block text-sm font-medium mb-2">Video Title</label>
                    <input type="text" name="title" required class="w-full border rounded-lg px-3 py-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-2">Video File (MP4)</label>
                    <input type="file" name="video" accept="video/mp4" required class="w-full border rounded-lg px-3 py-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-2">Duration (Optional)</label>
                    <input type="text" name="duration" placeholder="e.g. 10:30" class="w-full border rounded-lg px-3 py-2">
                </div>
                <div id="uploadProgress" class="hidden">
                    <div class="bg-gray-200 rounded-full h-2">
                        <div id="progressBar" class="bg-blue-600 h-2 rounded-full" style="width: 0%"></div>
                    </div>
                    <p id="progressText" class="text-sm text-center mt-2">Uploading...</p>
                </div>
                <div class="flex space-x-2">
                    <button type="submit" class="flex-1 bg-blue-600 text-white py-2 rounded-lg">Upload</button>
                    <button type="button" onclick="closeModal()" class="flex-1 bg-gray-300 py-2 rounded-lg">Cancel</button>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
function openAddModal() {
    document.getElementById('addModal').classList.remove('hidden');
    document.getElementById('addModal').classList.add('flex');
}

function closeModal() {
    document.getElementById('addModal').classList.add('hidden');
}

document.getElementById('videoForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    
    document.getElementById('uploadProgress').classList.remove('hidden');
    
    const xhr = new XMLHttpRequest();
    
    xhr.upload.addEventListener('progress', function(e) {
        if (e.lengthComputable) {
            const percentComplete = (e.loaded / e.total) * 100;
            document.getElementById('progressBar').style.width = percentComplete + '%';
            document.getElementById('progressText').textContent = Math.round(percentComplete) + '% uploaded';
        }
    });
    
    xhr.addEventListener('load', function() {
        if (xhr.status === 200) {
            const data = JSON.parse(xhr.responseText);
            if (data.success) {
                showToast(data.message, 'success');
                setTimeout(() => location.reload(), 1000);
            } else {
                showToast(data.message, 'error');
                document.getElementById('uploadProgress').classList.add('hidden');
            }
        }
    });
    
    xhr.open('POST', 'ajax/video_upload.php');
    xhr.send(formData);
});

function deleteVideo(id) {
    if (confirm('Delete this video?')) {
        fetch('ajax/video_delete.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: `id=${id}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showToast(data.message, 'success');
                setTimeout(() => location.reload(), 1000);
            }
        });
    }
}
</script>
