<?php
require_once '../../common/config.php';

if (!isAdminLoggedIn()) {
    jsonResponse(false, 'Unauthorized');
}

foreach ($_POST as $key => $value) {
    if ($key !== 'submit') {
        $key_safe = sanitize($key);
        $value_safe = sanitize($value);
        
        // Check if setting exists
        $check = mysqli_query($conn, "SELECT id FROM settings WHERE setting_key = '$key_safe'");
        
        if (mysqli_num_rows($check) > 0) {
            // Update
            mysqli_query($conn, "UPDATE settings SET setting_value = '$value_safe' WHERE setting_key = '$key_safe'");
        } else {
            // Insert
            mysqli_query($conn, "INSERT INTO settings (setting_key, setting_value) VALUES ('$key_safe', '$value_safe')");
        }
    }
}

jsonResponse(true, 'Settings saved successfully');
?>
