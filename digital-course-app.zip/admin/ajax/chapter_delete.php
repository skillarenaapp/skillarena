<?php
require_once '../../common/config.php';

if (!isAdminLoggedIn()) {
    jsonResponse(false, 'Unauthorized');
}

$id = intval($_POST['id'] ?? 0);

if ($id === 0) {
    jsonResponse(false, 'Invalid chapter');
}

$delete = "DELETE FROM chapters WHERE id = $id";

if (mysqli_query($conn, $delete)) {
    jsonResponse(true, 'Chapter deleted successfully');
} else {
    jsonResponse(false, 'Failed to delete chapter');
}
?>
