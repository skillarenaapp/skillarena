<?php
require_once '../../common/config.php';

if (!isAdminLoggedIn()) {
    jsonResponse(false, 'Unauthorized');
}

$id = intval($_POST['id'] ?? 0);
$status = intval($_POST['status'] ?? 0);

if ($id === 0) {
    jsonResponse(false, 'Invalid banner');
}

$update = "UPDATE banners SET status = $status WHERE id = $id";

if (mysqli_query($conn, $update)) {
    jsonResponse(true, 'Banner status updated');
} else {
    jsonResponse(false, 'Failed to update status');
}
?>
