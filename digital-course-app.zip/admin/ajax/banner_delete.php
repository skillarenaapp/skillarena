<?php
require_once '../../common/config.php';

if (!isAdminLoggedIn()) {
    jsonResponse(false, 'Unauthorized');
}

$id = intval($_POST['id'] ?? 0);

if ($id === 0) {
    jsonResponse(false, 'Invalid banner');
}

// Get image path to delete file
$banner_query = mysqli_query($conn, "SELECT image FROM banners WHERE id = $id");
if (mysqli_num_rows($banner_query) > 0) {
    $banner = mysqli_fetch_assoc($banner_query);
    if (file_exists('../../' . $banner['image'])) {
        unlink('../../' . $banner['image']);
    }
}

$delete = "DELETE FROM banners WHERE id = $id";

if (mysqli_query($conn, $delete)) {
    jsonResponse(true, 'Banner deleted successfully');
} else {
    jsonResponse(false, 'Failed to delete banner');
}
?>
