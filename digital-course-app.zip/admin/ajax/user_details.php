<?php
require_once '../../common/config.php';

if (!isAdminLoggedIn()) {
    jsonResponse(false, 'Unauthorized');
}

$user_id = intval($_GET['id'] ?? 0);

if ($user_id === 0) {
    jsonResponse(false, 'Invalid user');
}

$user_query = "SELECT * FROM users WHERE id = $user_id";
$user = mysqli_fetch_assoc(mysqli_query($conn, $user_query));

$purchases_query = "SELECT p.*, c.title as course_title 
                    FROM purchases p 
                    INNER JOIN courses c ON p.course_id = c.id 
                    WHERE p.user_id = $user_id AND p.status = 'success' 
                    ORDER BY p.created_at DESC";
$purchases = mysqli_query($conn, $purchases_query);

ob_start();
?>
<div class="space-y-4">
    <div class="grid grid-cols-2 gap-4">
        <div>
            <p class="text-sm text-gray-600">Name</p>
            <p class="font-semibold"><?php echo htmlspecialchars($user['name']); ?></p>
        </div>
        <div>
            <p class="text-sm text-gray-600">Email</p>
            <p class="font-semibold"><?php echo htmlspecialchars($user['email']); ?></p>
        </div>
        <div>
            <p class="text-sm text-gray-600">Phone</p>
            <p class="font-semibold"><?php echo htmlspecialchars($user['phone']); ?></p>
        </div>
        <div>
            <p class="text-sm text-gray-600">Joined</p>
            <p class="font-semibold"><?php echo date('M d, Y', strtotime($user['created_at'])); ?></p>
        </div>
    </div>
    
    <hr>
    
    <h3 class="font-semibold text-lg">Purchased Courses</h3>
    <div class="space-y-2">
        <?php while ($purchase = mysqli_fetch_assoc($purchases)): ?>
            <div class="flex justify-between items-center p-3 bg-gray-50 rounded">
                <div>
                    <p class="font-medium"><?php echo htmlspecialchars($purchase['course_title']); ?></p>
                    <p class="text-sm text-gray-600">Rs <?php echo number_format($purchase['amount'], 2); ?></p>
                </div>
                <p class="text-sm text-gray-500"><?php echo date('M d, Y', strtotime($purchase['created_at'])); ?></p>
            </div>
        <?php endwhile; ?>
    </div>
</div>
<?php
$html = ob_get_clean();
jsonResponse(true, '', ['html' => $html]);
?>
