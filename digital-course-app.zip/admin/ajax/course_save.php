<?php
require_once '../../common/config.php';

if (!isAdminLoggedIn()) {
    jsonResponse(false, 'Unauthorized');
}

$course_id = intval($_POST['course_id'] ?? 0);
$title = sanitize($_POST['title'] ?? '');
$category = sanitize($_POST['category'] ?? '');
$description = sanitize($_POST['description'] ?? '');
$mrp = floatval($_POST['mrp'] ?? 0);
$price = floatval($_POST['price'] ?? 0);

if (empty($title) || $mrp <= 0 || $price <= 0) {
    jsonResponse(false, 'Please fill all required fields');
}

$thumbnail = '';

// Handle thumbnail upload
if (isset($_FILES['thumbnail']) && $_FILES['thumbnail']['error'] === UPLOAD_ERR_OK) {
    $upload_dir = '../../uploads/courses/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }
    
    $extension = pathinfo($_FILES['thumbnail']['name'], PATHINFO_EXTENSION);
    $filename = 'course_' . time() . '_' . rand(1000, 9999) . '.' . $extension;
    $filepath = $upload_dir . $filename;
    
    if (move_uploaded_file($_FILES['thumbnail']['tmp_name'], $filepath)) {
        $thumbnail = 'uploads/courses/' . $filename;
    }
}

if ($course_id > 0) {
    // Update
    $update = "UPDATE courses SET title = '$title', category = '$category', description = '$description', mrp = $mrp, price = $price";
    if ($thumbnail) {
        $update .= ", thumbnail = '$thumbnail'";
    }
    $update .= " WHERE id = $course_id";
    
    if (mysqli_query($conn, $update)) {
        jsonResponse(true, 'Course updated successfully');
    } else {
        jsonResponse(false, 'Failed to update course');
    }
} else {
    // Insert
    if (empty($thumbnail)) {
        jsonResponse(false, 'Please upload a thumbnail');
    }
    
    $insert = "INSERT INTO courses (title, category, description, thumbnail, mrp, price) 
               VALUES ('$title', '$category', '$description', '$thumbnail', $mrp, $price)";
    
    if (mysqli_query($conn, $insert)) {
        jsonResponse(true, 'Course added successfully');
    } else {
        jsonResponse(false, 'Failed to add course');
    }
}
?>
