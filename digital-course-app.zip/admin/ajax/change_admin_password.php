<?php
require_once '../../common/config.php';

if (!isAdminLoggedIn()) {
    jsonResponse(false, 'Unauthorized');
}

$admin_id = $_SESSION['admin_id'];
$current_password = $_POST['current_password'] ?? '';
$new_password = $_POST['new_password'] ?? '';

if (empty($current_password) || empty($new_password)) {
    jsonResponse(false, 'Please fill all fields');
}

if (strlen($new_password) < 6) {
    jsonResponse(false, 'Password must be at least 6 characters');
}

// Verify current password
$admin_query = "SELECT password FROM admin WHERE id = $admin_id";
$admin = mysqli_fetch_assoc(mysqli_query($conn, $admin_query));

if (!password_verify($current_password, $admin['password'])) {
    jsonResponse(false, 'Current password is incorrect');
}

// Update password
$hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
$update = "UPDATE admin SET password = '$hashed_password' WHERE id = $admin_id";

if (mysqli_query($conn, $update)) {
    jsonResponse(true, 'Password changed successfully');
} else {
    jsonResponse(false, 'Failed to change password');
}
?>
