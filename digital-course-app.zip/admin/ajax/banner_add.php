<?php
require_once '../../common/config.php';

if (!isAdminLoggedIn()) {
    jsonResponse(false, 'Unauthorized');
}

$link = sanitize($_POST['link'] ?? '');

// Handle file upload
if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
    jsonResponse(false, 'Please upload an image');
}

$allowed = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
if (!in_array($_FILES['image']['type'], $allowed)) {
    jsonResponse(false, 'Invalid image format');
}

$upload_dir = '../../uploads/banners/';
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

$extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
$filename = 'banner_' . time() . '_' . rand(1000, 9999) . '.' . $extension;
$filepath = $upload_dir . $filename;

if (move_uploaded_file($_FILES['image']['tmp_name'], $filepath)) {
    $image_url = 'uploads/banners/' . $filename;
    $insert = "INSERT INTO banners (image, link) VALUES ('$image_url', '$link')";
    
    if (mysqli_query($conn, $insert)) {
        jsonResponse(true, 'Banner added successfully');
    } else {
        jsonResponse(false, 'Failed to save banner');
    }
} else {
    jsonResponse(false, 'Failed to upload image');
}
?>
