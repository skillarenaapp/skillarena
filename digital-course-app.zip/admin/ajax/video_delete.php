<?php
require_once '../../common/config.php';

if (!isAdminLoggedIn()) {
    jsonResponse(false, 'Unauthorized');
}

$id = intval($_POST['id'] ?? 0);

if ($id === 0) {
    jsonResponse(false, 'Invalid video');
}

// Get video file path to delete
$video_query = mysqli_query($conn, "SELECT video_url FROM videos WHERE id = $id");
if (mysqli_num_rows($video_query) > 0) {
    $video = mysqli_fetch_assoc($video_query);
    if (file_exists('../../' . $video['video_url'])) {
        unlink('../../' . $video['video_url']);
    }
}

$delete = "DELETE FROM videos WHERE id = $id";

if (mysqli_query($conn, $delete)) {
    jsonResponse(true, 'Video deleted successfully');
} else {
    jsonResponse(false, 'Failed to delete video');
}
?>
