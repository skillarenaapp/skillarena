<?php
require_once '../../common/config.php';

if (!isAdminLoggedIn()) {
    jsonResponse(false, 'Unauthorized');
}

$course_id = intval($_POST['course_id'] ?? 0);
$title = sanitize($_POST['title'] ?? '');

if ($course_id === 0 || empty($title)) {
    jsonResponse(false, 'Invalid data');
}

$sort_order = mysqli_fetch_assoc(mysqli_query($conn, "SELECT MAX(sort_order) as max_order FROM chapters WHERE course_id = $course_id"))['max_order'] ?? 0;
$sort_order++;

$insert = "INSERT INTO chapters (course_id, title, sort_order) VALUES ($course_id, '$title', $sort_order)";

if (mysqli_query($conn, $insert)) {
    jsonResponse(true, 'Chapter added successfully');
} else {
    jsonResponse(false, 'Failed to add chapter');
}
?>
