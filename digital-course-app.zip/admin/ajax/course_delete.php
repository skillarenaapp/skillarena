<?php
require_once '../../common/config.php';

if (!isAdminLoggedIn()) {
    jsonResponse(false, 'Unauthorized');
}

$id = intval($_POST['id'] ?? 0);

if ($id === 0) {
    jsonResponse(false, 'Invalid course');
}

$delete = "DELETE FROM courses WHERE id = $id";

if (mysqli_query($conn, $delete)) {
    jsonResponse(true, 'Course deleted successfully');
} else {
    jsonResponse(false, 'Failed to delete course');
}
?>
