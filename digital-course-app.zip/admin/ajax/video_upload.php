<?php
require_once '../../common/config.php';

if (!isAdminLoggedIn()) {
    jsonResponse(false, 'Unauthorized');
}

$chapter_id = intval($_POST['chapter_id'] ?? 0);
$title = sanitize($_POST['title'] ?? '');
$duration = sanitize($_POST['duration'] ?? '');

if ($chapter_id === 0 || empty($title)) {
    jsonResponse(false, 'Invalid data');
}

if (!isset($_FILES['video']) || $_FILES['video']['error'] !== UPLOAD_ERR_OK) {
    jsonResponse(false, 'Please upload a video file');
}

if ($_FILES['video']['type'] !== 'video/mp4') {
    jsonResponse(false, 'Only MP4 videos are allowed');
}

$upload_dir = '../../uploads/videos/';
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

$filename = 'video_' . time() . '_' . rand(1000, 9999) . '.mp4';
$filepath = $upload_dir . $filename;

if (move_uploaded_file($_FILES['video']['tmp_name'], $filepath)) {
    $video_url = 'uploads/videos/' . $filename;
    
    $sort_order = mysqli_fetch_assoc(mysqli_query($conn, "SELECT MAX(sort_order) as max_order FROM videos WHERE chapter_id = $chapter_id"))['max_order'] ?? 0;
    $sort_order++;
    
    $insert = "INSERT INTO videos (chapter_id, title, video_url, duration, sort_order) VALUES ($chapter_id, '$title', '$video_url', '$duration', $sort_order)";
    
    if (mysqli_query($conn, $insert)) {
        jsonResponse(true, 'Video uploaded successfully');
    } else {
        unlink($filepath);
        jsonResponse(false, 'Failed to save video');
    }
} else {
    jsonResponse(false, 'Failed to upload video');
}
?>
