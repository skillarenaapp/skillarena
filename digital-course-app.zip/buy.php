<?php
require_once 'common/config.php';

// Check if user is logged in
if (!isUserLoggedIn()) {
    redirect('login.php');
}

$course_id = intval($_GET['course_id'] ?? 0);

if ($course_id === 0) {
    redirect('course.php');
}

// Fetch course details
$course_query = "SELECT * FROM courses WHERE id = $course_id AND status = 1";
$course_result = mysqli_query($conn, $course_query);

if (mysqli_num_rows($course_result) === 0) {
    redirect('course.php');
}

$course = mysqli_fetch_assoc($course_result);
$user_id = $_SESSION['user_id'];

// Check if already purchased
$purchase_check = "SELECT id FROM purchases WHERE user_id = $user_id AND course_id = $course_id AND status = 'success'";
$purchase_result = mysqli_query($conn, $purchase_check);

if (mysqli_num_rows($purchase_result) > 0) {
    redirect('mycourses.php');
}

// Get Cashfree credentials from settings
$cf_app_id_query = mysqli_query($conn, "SELECT setting_value FROM settings WHERE setting_key = 'cashfree_app_id'");
$cf_secret_query = mysqli_query($conn, "SELECT setting_value FROM settings WHERE setting_key = 'cashfree_secret_key'");
$cf_test_mode_query = mysqli_query($conn, "SELECT setting_value FROM settings WHERE setting_key = 'cashfree_test_mode'");

$cf_app_id = mysqli_num_rows($cf_app_id_query) > 0 ? mysqli_fetch_assoc($cf_app_id_query)['setting_value'] : '';
$cf_secret = mysqli_num_rows($cf_secret_query) > 0 ? mysqli_fetch_assoc($cf_secret_query)['setting_value'] : '';
$cf_test_mode = mysqli_num_rows($cf_test_mode_query) > 0 ? mysqli_fetch_assoc($cf_test_mode_query)['setting_value'] : '1';

$page_title = 'Checkout';
$show_back = true;
include 'common/header.php';
?>

<div class="bg-white">
    <!-- Order Summary -->
    <div class="p-4 border-b">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Order Summary</h2>
        
        <div class="flex items-start space-x-4 mb-4">
            <img src="<?php echo htmlspecialchars($course['thumbnail']); ?>" 
                alt="<?php echo htmlspecialchars($course['title']); ?>" 
                class="w-24 h-16 object-cover rounded">
            <div class="flex-1">
                <h3 class="font-semibold text-gray-800">
                    <?php echo htmlspecialchars($course['title']); ?>
                </h3>
                <p class="text-sm text-gray-500">Digital Course</p>
            </div>
        </div>
        
        <div class="space-y-2 text-sm">
            <div class="flex justify-between">
                <span class="text-gray-600">Original Price</span>
                <span class="text-gray-800">Rs <?php echo number_format($course['mrp'], 2); ?></span>
            </div>
            <?php if ($course['mrp'] > $course['price']): ?>
            <div class="flex justify-between text-green-600">
                <span>Discount</span>
                <span>- Rs <?php echo number_format($course['mrp'] - $course['price'], 2); ?></span>
            </div>
            <?php endif; ?>
            <hr>
            <div class="flex justify-between text-lg font-bold">
                <span>Total Amount</span>
                <span class="text-blue-600">Rs <?php echo number_format($course['price'], 2); ?></span>
            </div>
        </div>
    </div>
    
    <!-- Payment Methods -->
    <div class="p-4">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">Payment Method</h3>
        
        <?php if (empty($cf_app_id) || empty($cf_secret)): ?>
            <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-4">
                <p class="text-yellow-800 text-sm">
                    <i class="fas fa-exclamation-triangle mr-2"></i>
                    Payment gateway not configured. Please contact admin.
                </p>
            </div>
        <?php else: ?>
            <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                <div class="flex items-center space-x-3">
                    <i class="fas fa-credit-card text-2xl text-blue-600"></i>
                    <div>
                        <h4 class="font-semibold text-gray-800">Cashfree Payment Gateway</h4>
                        <p class="text-sm text-gray-600">UPI, Cards, Net Banking & More</p>
                    </div>
                </div>
            </div>
            
            <button id="payNowBtn" 
                class="w-full bg-blue-600 text-white py-4 rounded-lg font-semibold hover:bg-blue-700 transition">
                <i class="fas fa-lock mr-2"></i> Proceed to Pay Rs <?php echo number_format($course['price'], 2); ?>
            </button>
        <?php endif; ?>
    </div>
</div>

<script>
document.getElementById('payNowBtn')?.addEventListener('click', function() {
    showLoading();
    
    // Create order via AJAX
    fetch('ajax/create_order.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `course_id=<?php echo $course_id; ?>`
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        
        if (data.success) {
            // In production, integrate with Cashfree SDK
            // For now, simulate payment success after 2 seconds
            showToast('Redirecting to payment gateway...', 'info');
            
            setTimeout(() => {
                // Simulate payment success
                window.location.href = `payment_success.php?order_id=${data.order_id}`;
            }, 2000);
        } else {
            showToast(data.message, 'error');
        }
    })
    .catch(error => {
        hideLoading();
        showToast('Payment initialization failed', 'error');
    });
});
</script>

<?php include 'common/bottom.php'; ?>
