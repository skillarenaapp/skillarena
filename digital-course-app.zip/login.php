<?php
require_once 'common/config.php';

// Redirect if already logged in
if (isUserLoggedIn()) {
    redirect('index.php');
}

$page_title = 'Login';
include 'common/header.php';
?>

<div class="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-blue-50 to-blue-100">
    <div class="w-full max-w-md">
        <!-- Logo/Brand -->
        <div class="text-center mb-8">
            <h1 class="text-4xl font-bold text-blue-600 mb-2">SkillzUp</h1>
            <p class="text-gray-600">Learn Anytime, Anywhere</p>
        </div>
        
        <!-- Tab Navigation -->
        <div class="bg-white rounded-t-lg shadow-lg">
            <div class="flex border-b">
                <button id="loginTab" class="flex-1 py-4 font-semibold text-blue-600 border-b-2 border-blue-600">
                    Login
                </button>
                <button id="signupTab" class="flex-1 py-4 font-semibold text-gray-500">
                    Sign Up
                </button>
            </div>
            
            <!-- Login Form -->
            <div id="loginForm" class="p-6">
                <form id="loginFormSubmit" class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Email</label>
                        <input type="email" name="email" required 
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            placeholder="Enter your email">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Password</label>
                        <input type="password" name="password" required 
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            placeholder="Enter your password">
                    </div>
                    
                    <button type="submit" 
                        class="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition">
                        Login
                    </button>
                </form>
            </div>
            
            <!-- Signup Form -->
            <div id="signupForm" class="p-6 hidden">
                <form id="signupFormSubmit" class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                        <input type="text" name="name" required 
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            placeholder="Enter your full name">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                        <input type="tel" name="phone" required 
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            placeholder="Enter your phone number">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Email</label>
                        <input type="email" name="email" required 
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            placeholder="Enter your email">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Password</label>
                        <input type="password" name="password" required minlength="6"
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            placeholder="Create a password (min 6 characters)">
                    </div>
                    
                    <button type="submit" 
                        class="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition">
                        Sign Up
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
// Tab switching
const loginTab = document.getElementById('loginTab');
const signupTab = document.getElementById('signupTab');
const loginForm = document.getElementById('loginForm');
const signupForm = document.getElementById('signupForm');

loginTab.addEventListener('click', () => {
    loginTab.classList.add('text-blue-600', 'border-b-2', 'border-blue-600');
    loginTab.classList.remove('text-gray-500');
    signupTab.classList.remove('text-blue-600', 'border-b-2', 'border-blue-600');
    signupTab.classList.add('text-gray-500');
    loginForm.classList.remove('hidden');
    signupForm.classList.add('hidden');
});

signupTab.addEventListener('click', () => {
    signupTab.classList.add('text-blue-600', 'border-b-2', 'border-blue-600');
    signupTab.classList.remove('text-gray-500');
    loginTab.classList.remove('text-blue-600', 'border-b-2', 'border-blue-600');
    loginTab.classList.add('text-gray-500');
    signupForm.classList.remove('hidden');
    loginForm.classList.add('hidden');
});

// Login form submission
document.getElementById('loginFormSubmit').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    showLoading();
    
    fetch('ajax/login.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showToast(data.message, 'success');
            setTimeout(() => {
                window.location.href = 'index.php';
            }, 1000);
        } else {
            showToast(data.message, 'error');
        }
    })
    .catch(error => {
        hideLoading();
        showToast('An error occurred. Please try again.', 'error');
    });
});

// Signup form submission
document.getElementById('signupFormSubmit').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    showLoading();
    
    fetch('ajax/signup.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showToast(data.message, 'success');
            setTimeout(() => {
                window.location.href = 'index.php';
            }, 1000);
        } else {
            showToast(data.message, 'error');
        }
    })
    .catch(error => {
        hideLoading();
        showToast('An error occurred. Please try again.', 'error');
    });
});
</script>

<?php include 'common/bottom.php'; ?>
