<?php
require_once 'common/config.php';

$page_title = 'Home';
include 'common/header.php';

// Fetch banners
$banners_query = "SELECT * FROM banners WHERE status = 1 ORDER BY id DESC";
$banners_result = mysqli_query($conn, $banners_query);

// Fetch latest courses
$courses_query = "SELECT * FROM courses WHERE status = 1 ORDER BY created_at DESC LIMIT 10";
$courses_result = mysqli_query($conn, $courses_query);
?>

<!-- Search Bar -->
<div class="px-4 py-4 bg-white">
    <div class="relative">
        <input type="text" id="searchInput" 
            placeholder="Search courses..." 
            class="w-full pl-10 pr-4 py-3 bg-gray-100 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500">
        <i class="fas fa-search absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
    </div>
</div>

<!-- Banner Slider -->
<?php if (mysqli_num_rows($banners_result) > 0): ?>
<div class="px-4 py-4">
    <div class="relative overflow-hidden rounded-lg">
        <div id="bannerSlider" class="flex transition-transform duration-500 ease-in-out">
            <?php while ($banner = mysqli_fetch_assoc($banners_result)): ?>
                <div class="min-w-full">
                    <?php if ($banner['link']): ?>
                        <a href="<?php echo htmlspecialchars($banner['link']); ?>">
                            <img src="<?php echo htmlspecialchars($banner['image']); ?>" 
                                alt="Banner" 
                                class="w-full aspect-video object-cover rounded-lg">
                        </a>
                    <?php else: ?>
                        <img src="<?php echo htmlspecialchars($banner['image']); ?>" 
                            alt="Banner" 
                            class="w-full aspect-video object-cover rounded-lg">
                    <?php endif; ?>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Latest Courses Section -->
<div class="px-4 py-4">
    <div class="flex items-center justify-between mb-4">
        <h2 class="text-xl font-bold text-gray-800">Latest Courses</h2>
        <a href="course.php" class="text-blue-600 text-sm font-semibold">View All</a>
    </div>
    
    <div class="flex overflow-x-auto hide-scrollbar space-x-4 pb-2">
        <?php if (mysqli_num_rows($courses_result) > 0): ?>
            <?php while ($course = mysqli_fetch_assoc($courses_result)): ?>
                <a href="course_detail.php?id=<?php echo $course['id']; ?>" 
                    class="flex-shrink-0 w-64 bg-white rounded-lg shadow-md overflow-hidden">
                    <img src="<?php echo htmlspecialchars($course['thumbnail']); ?>" 
                        alt="<?php echo htmlspecialchars($course['title']); ?>" 
                        class="w-full aspect-video object-cover">
                    <div class="p-4">
                        <h3 class="font-semibold text-gray-800 mb-2 line-clamp-2">
                            <?php echo htmlspecialchars($course['title']); ?>
                        </h3>
                        <div class="flex items-center space-x-2">
                            <span class="text-lg font-bold text-blue-600">
                                Rs <?php echo number_format($course['price'], 2); ?>
                            </span>
                            <?php if ($course['mrp'] > $course['price']): ?>
                                <span class="text-sm text-gray-400 line-through">
                                    Rs <?php echo number_format($course['mrp'], 2); ?>
                                </span>
                                <span class="text-xs bg-green-100 text-green-700 px-2 py-1 rounded">
                                    <?php echo round((($course['mrp'] - $course['price']) / $course['mrp']) * 100); ?>% OFF
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </a>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="w-full text-center py-8 text-gray-500">
                <i class="fas fa-book text-4xl mb-2"></i>
                <p>No courses available yet</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
// Banner auto-slider
const bannerSlider = document.getElementById('bannerSlider');
if (bannerSlider) {
    const slides = bannerSlider.children.length;
    let currentSlide = 0;
    
    setInterval(() => {
        currentSlide = (currentSlide + 1) % slides;
        bannerSlider.style.transform = `translateX(-${currentSlide * 100}%)`;
    }, 3000);
}

// Search functionality
document.getElementById('searchInput').addEventListener('input', function(e) {
    const searchTerm = e.target.value.toLowerCase();
    if (searchTerm.length > 2) {
        window.location.href = `course.php?search=${encodeURIComponent(searchTerm)}`;
    }
});
</script>

<?php include 'common/bottom.php'; ?>
