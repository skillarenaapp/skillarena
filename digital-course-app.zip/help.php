<?php
require_once 'common/config.php';

// Fetch support info from settings
$support_email_query = mysqli_query($conn, "SELECT setting_value FROM settings WHERE setting_key = 'support_email'");
$support_phone_query = mysqli_query($conn, "SELECT setting_value FROM settings WHERE setting_key = 'support_phone'");

$support_email = mysqli_num_rows($support_email_query) > 0 ? mysqli_fetch_assoc($support_email_query)['setting_value'] : 'support@skillzup.com';
$support_phone = mysqli_num_rows($support_phone_query) > 0 ? mysqli_fetch_assoc($support_phone_query)['setting_value'] : '+1234567890';

$page_title = 'Help & Support';
include 'common/header.php';
?>

<div class="p-4">
    <!-- Header -->
    <div class="text-center mb-8">
        <div class="w-20 h-20 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <i class="fas fa-headset text-3xl text-white"></i>
        </div>
        <h1 class="text-2xl font-bold text-gray-800 mb-2">How can we help you?</h1>
        <p class="text-gray-600">We're here to assist you with any questions</p>
    </div>
    
    <!-- Contact Methods -->
    <div class="space-y-4 mb-8">
        <a href="mailto:<?php echo htmlspecialchars($support_email); ?>" 
            class="block bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition">
            <div class="flex items-center space-x-4">
                <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                    <i class="fas fa-envelope text-blue-600 text-xl"></i>
                </div>
                <div class="flex-1">
                    <h3 class="font-semibold text-gray-800 mb-1">Email Support</h3>
                    <p class="text-sm text-gray-600"><?php echo htmlspecialchars($support_email); ?></p>
                </div>
                <i class="fas fa-chevron-right text-gray-400"></i>
            </div>
        </a>
        
        <a href="tel:<?php echo htmlspecialchars($support_phone); ?>" 
            class="block bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition">
            <div class="flex items-center space-x-4">
                <div class="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                    <i class="fas fa-phone text-green-600 text-xl"></i>
                </div>
                <div class="flex-1">
                    <h3 class="font-semibold text-gray-800 mb-1">Phone Support</h3>
                    <p class="text-sm text-gray-600"><?php echo htmlspecialchars($support_phone); ?></p>
                </div>
                <i class="fas fa-chevron-right text-gray-400"></i>
            </div>
        </a>
    </div>
    
    <!-- FAQ Section -->
    <div class="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Frequently Asked Questions</h2>
        
        <div class="space-y-4">
            <div class="border-b pb-4">
                <h4 class="font-semibold text-gray-800 mb-2">How do I purchase a course?</h4>
                <p class="text-sm text-gray-600">Browse courses, select the one you want, and click "Buy Now". Complete the payment to get instant access.</p>
            </div>
            
            <div class="border-b pb-4">
                <h4 class="font-semibold text-gray-800 mb-2">Can I access courses offline?</h4>
                <p class="text-sm text-gray-600">Currently, courses require an internet connection to watch. Offline access is coming soon.</p>
            </div>
            
            <div class="border-b pb-4">
                <h4 class="font-semibold text-gray-800 mb-2">What payment methods are accepted?</h4>
                <p class="text-sm text-gray-600">We accept UPI, Credit/Debit Cards, Net Banking, and various digital wallets through our secure payment gateway.</p>
            </div>
            
            <div class="border-b pb-4">
                <h4 class="font-semibold text-gray-800 mb-2">Do courses have lifetime access?</h4>
                <p class="text-sm text-gray-600">Yes! Once you purchase a course, you have lifetime access to all its content.</p>
            </div>
            
            <div class="pb-4">
                <h4 class="font-semibold text-gray-800 mb-2">How do I reset my password?</h4>
                <p class="text-sm text-gray-600">Go to Profile > Change Password to update your password. You'll need your current password to make changes.</p>
            </div>
        </div>
    </div>
    
    <!-- App Info -->
    <div class="text-center text-gray-500 text-sm">
        <p class="mb-2">SkillzUp - Learn Anytime, Anywhere</p>
        <p>Version 1.0.0</p>
    </div>
</div>

<?php include 'common/bottom.php'; ?>
