<!-- Sidebar -->
<aside id="sidebar" class="sidebar fixed top-0 left-0 h-full w-72 bg-white shadow-lg z-50 overflow-y-auto">
    <div class="p-4">
        <!-- User Info Section -->
        <?php if (isUserLoggedIn()): ?>
            <?php
            $user_id = $_SESSION['user_id'];
            $user_query = mysqli_query($conn, "SELECT * FROM users WHERE id = $user_id");
            $user = mysqli_fetch_assoc($user_query);
            ?>
            <div class="flex items-center space-x-3 mb-6 pb-4 border-b">
                <div class="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white text-xl font-bold">
                    <?php echo strtoupper(substr($user['name'], 0, 1)); ?>
                </div>
                <div class="flex-1">
                    <h3 class="font-semibold text-gray-800"><?php echo htmlspecialchars($user['name']); ?></h3>
                    <p class="text-sm text-gray-500"><?php echo htmlspecialchars($user['email']); ?></p>
                </div>
            </div>
        <?php else: ?>
            <div class="mb-6 pb-4 border-b">
                <h3 class="font-semibold text-gray-800 mb-2">Welcome to SkillzUp</h3>
                <a href="login.php" class="text-blue-600 text-sm hover:underline">Login / Sign Up</a>
            </div>
        <?php endif; ?>
        
        <!-- Navigation Links -->
        <nav class="space-y-1">
            <a href="index.php" class="flex items-center space-x-3 px-4 py-3 rounded-lg hover:bg-gray-100 <?php echo $current_page == 'index' ? 'bg-blue-50 text-blue-600' : 'text-gray-700'; ?>">
                <i class="fas fa-home w-5"></i>
                <span>Home</span>
            </a>
            
            <a href="course.php" class="flex items-center space-x-3 px-4 py-3 rounded-lg hover:bg-gray-100 <?php echo $current_page == 'course' ? 'bg-blue-50 text-blue-600' : 'text-gray-700'; ?>">
                <i class="fas fa-book w-5"></i>
                <span>All Courses</span>
            </a>
            
            <?php if (isUserLoggedIn()): ?>
            <a href="mycourses.php" class="flex items-center space-x-3 px-4 py-3 rounded-lg hover:bg-gray-100 <?php echo $current_page == 'mycourses' ? 'bg-blue-50 text-blue-600' : 'text-gray-700'; ?>">
                <i class="fas fa-graduation-cap w-5"></i>
                <span>My Courses</span>
            </a>
            
            <a href="profile.php" class="flex items-center space-x-3 px-4 py-3 rounded-lg hover:bg-gray-100 <?php echo $current_page == 'profile' ? 'bg-blue-50 text-blue-600' : 'text-gray-700'; ?>">
                <i class="fas fa-user w-5"></i>
                <span>Profile</span>
            </a>
            <?php endif; ?>
            
            <a href="help.php" class="flex items-center space-x-3 px-4 py-3 rounded-lg hover:bg-gray-100 <?php echo $current_page == 'help' ? 'bg-blue-50 text-blue-600' : 'text-gray-700'; ?>">
                <i class="fas fa-question-circle w-5"></i>
                <span>Help & Support</span>
            </a>
            
            <?php if (isUserLoggedIn()): ?>
            <hr class="my-2">
            <a href="logout.php" class="flex items-center space-x-3 px-4 py-3 rounded-lg hover:bg-red-50 text-red-600">
                <i class="fas fa-sign-out-alt w-5"></i>
                <span>Logout</span>
            </a>
            <?php endif; ?>
        </nav>
    </div>
</aside>
