<?php
if (!isset($_SESSION)) {
    session_start();
}

$page_title = isset($page_title) ? $page_title : 'SkillzUp';
$show_back = isset($show_back) ? $show_back : false;
$current_page = basename($_SERVER['PHP_SELF'], '.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="mobile-web-app-capable" content="yes">
    <title><?php echo htmlspecialchars($page_title); ?> - SkillzUp</title>
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <style>
        /* Disable text selection */
        * {
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
            -webkit-touch-callout: none;
        }
        
        /* Allow selection for input fields */
        input, textarea {
            -webkit-user-select: text;
            -moz-user-select: text;
            -ms-user-select: text;
            user-select: text;
        }
        
        /* Disable pinch zoom */
        html {
            touch-action: pan-x pan-y;
        }
        
        /* Smooth scrolling */
        html {
            scroll-behavior: smooth;
        }
        
        /* Hide scrollbar but keep functionality */
        .hide-scrollbar::-webkit-scrollbar {
            display: none;
        }
        .hide-scrollbar {
            -ms-overflow-style: none;
            scrollbar-width: none;
        }
        
        /* Custom video player styles */
        video::-webkit-media-controls-download-button {
            display: none !important;
        }
        video::-webkit-media-controls-enclosure {
            overflow: hidden;
        }
        video::-webkit-media-controls-panel {
            width: calc(100% + 30px);
        }
        
        /* Sidebar animation */
        .sidebar {
            transform: translateX(-100%);
            transition: transform 0.3s ease-in-out;
        }
        .sidebar.active {
            transform: translateX(0);
        }
        
        /* Bottom navigation safe area */
        .bottom-nav {
            padding-bottom: env(safe-area-inset-bottom);
        }
    </style>
</head>
<body class="bg-gray-50">
    
    <!-- Top Header -->
    <header class="bg-white shadow-sm fixed top-0 left-0 right-0 z-40">
        <div class="flex items-center justify-between px-4 py-3">
            <!-- Left: Menu or Back Button -->
            <button id="menuBtn" class="text-gray-700 text-xl w-10 h-10 flex items-center justify-center">
                <?php if ($show_back): ?>
                    <i class="fas fa-arrow-left"></i>
                <?php else: ?>
                    <i class="fas fa-bars"></i>
                <?php endif; ?>
            </button>
            
            <!-- Center: App Name -->
            <h1 class="text-xl font-bold text-blue-600 flex-1 text-center">SkillzUp</h1>
            
            <!-- Right: Profile Icon -->
            <?php if (isUserLoggedIn()): ?>
                <a href="profile.php" class="text-gray-700 text-xl w-10 h-10 flex items-center justify-center">
                    <i class="fas fa-user-circle"></i>
                </a>
            <?php else: ?>
                <a href="login.php" class="text-gray-700 text-xl w-10 h-10 flex items-center justify-center">
                    <i class="fas fa-sign-in-alt"></i>
                </a>
            <?php endif; ?>
        </div>
    </header>
    
    <!-- Sidebar Overlay -->
    <div id="sidebarOverlay" class="fixed inset-0 bg-black bg-opacity-50 z-40 hidden"></div>
    
    <!-- Main Content Wrapper -->
    <main class="pt-16 pb-20">
