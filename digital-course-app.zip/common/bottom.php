<!-- Bottom Navigation -->
<nav class="bottom-nav fixed bottom-0 left-0 right-0 bg-white shadow-lg border-t z-30">
    <div class="flex items-center justify-around py-2">
        <a href="index.php" class="flex flex-col items-center justify-center py-2 px-4 <?php echo $current_page == 'index' ? 'text-blue-600' : 'text-gray-600'; ?>">
            <i class="fas fa-home text-xl mb-1"></i>
            <span class="text-xs">Home</span>
        </a>
        
        <a href="course.php" class="flex flex-col items-center justify-center py-2 px-4 <?php echo $current_page == 'course' ? 'text-blue-600' : 'text-gray-600'; ?>">
            <i class="fas fa-book text-xl mb-1"></i>
            <span class="text-xs">Courses</span>
        </a>
        
        <?php if (isUserLoggedIn()): ?>
        <a href="mycourses.php" class="flex flex-col items-center justify-center py-2 px-4 <?php echo $current_page == 'mycourses' ? 'text-blue-600' : 'text-gray-600'; ?>">
            <i class="fas fa-graduation-cap text-xl mb-1"></i>
            <span class="text-xs">My Courses</span>
        </a>
        <?php endif; ?>
        
        <a href="help.php" class="flex flex-col items-center justify-center py-2 px-4 <?php echo $current_page == 'help' ? 'text-blue-600' : 'text-gray-600'; ?>">
            <i class="fas fa-question-circle text-xl mb-1"></i>
            <span class="text-xs">Help</span>
        </a>
        
        <a href="<?php echo isUserLoggedIn() ? 'profile.php' : 'login.php'; ?>" class="flex flex-col items-center justify-center py-2 px-4 <?php echo $current_page == 'profile' || $current_page == 'login' ? 'text-blue-600' : 'text-gray-600'; ?>">
            <i class="fas fa-user text-xl mb-1"></i>
            <span class="text-xs">Profile</span>
        </a>
    </div>
</nav>

<!-- Include Sidebar -->
<?php include 'common/sidebar.php'; ?>

<!-- Common JavaScript -->
<script>
// Disable right-click
document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
});

// Disable specific keyboard shortcuts
document.addEventListener('keydown', function(e) {
    // Disable F12, Ctrl+Shift+I, Ctrl+Shift+J, Ctrl+U
    if (e.keyCode == 123 || 
        (e.ctrlKey && e.shiftKey && (e.keyCode == 73 || e.keyCode == 74)) ||
        (e.ctrlKey && e.keyCode == 85)) {
        e.preventDefault();
        return false;
    }
});

// Sidebar functionality
const menuBtn = document.getElementById('menuBtn');
const sidebar = document.getElementById('sidebar');
const sidebarOverlay = document.getElementById('sidebarOverlay');

function openSidebar() {
    sidebar.classList.add('active');
    sidebarOverlay.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
}

function closeSidebar() {
    sidebar.classList.remove('active');
    sidebarOverlay.classList.add('hidden');
    document.body.style.overflow = '';
}

menuBtn.addEventListener('click', function() {
    const isBack = this.querySelector('.fa-arrow-left');
    if (isBack) {
        window.history.back();
    } else {
        openSidebar();
    }
});

sidebarOverlay.addEventListener('click', closeSidebar);

// Close sidebar on escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeSidebar();
    }
});

// Loading indicator
function showLoading() {
    const loader = document.createElement('div');
    loader.id = 'globalLoader';
    loader.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
    loader.innerHTML = '<div class="bg-white rounded-lg p-6"><i class="fas fa-spinner fa-spin text-4xl text-blue-600"></i></div>';
    document.body.appendChild(loader);
}

function hideLoading() {
    const loader = document.getElementById('globalLoader');
    if (loader) {
        loader.remove();
    }
}

// Toast notification
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `fixed top-20 left-4 right-4 p-4 rounded-lg shadow-lg z-50 ${
        type === 'success' ? 'bg-green-500' : 
        type === 'error' ? 'bg-red-500' : 
        type === 'warning' ? 'bg-yellow-500' : 'bg-blue-500'
    } text-white`;
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transition = 'opacity 0.3s';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}
</script>

</body>
</html>
