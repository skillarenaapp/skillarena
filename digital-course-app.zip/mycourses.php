<?php
require_once 'common/config.php';

// Check if user is logged in
if (!isUserLoggedIn()) {
    redirect('login.php');
}

$user_id = $_SESSION['user_id'];

// Fetch purchased courses
$query = "SELECT c.*, p.created_at as purchase_date 
          FROM courses c 
          INNER JOIN purchases p ON c.id = p.course_id 
          WHERE p.user_id = $user_id AND p.status = 'success' 
          ORDER BY p.created_at DESC";
$result = mysqli_query($conn, $query);

$page_title = 'My Courses';
include 'common/header.php';
?>

<div class="p-4">
    <h1 class="text-2xl font-bold text-gray-800 mb-6">My Courses</h1>
    
    <?php if (mysqli_num_rows($result) > 0): ?>
        <div class="space-y-4">
            <?php while ($course = mysqli_fetch_assoc($result)): ?>
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <div class="flex">
                        <img src="<?php echo htmlspecialchars($course['thumbnail']); ?>" 
                            alt="<?php echo htmlspecialchars($course['title']); ?>" 
                            class="w-32 h-24 object-cover">
                        <div class="flex-1 p-4">
                            <h3 class="font-semibold text-gray-800 mb-1">
                                <?php echo htmlspecialchars($course['title']); ?>
                            </h3>
                            <p class="text-sm text-gray-500 mb-3">
                                Purchased on <?php echo date('M d, Y', strtotime($course['purchase_date'])); ?>
                            </p>
                            <a href="watch.php?course_id=<?php echo $course['id']; ?>" 
                                class="inline-block bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-blue-700 transition">
                                <i class="fas fa-play mr-1"></i> Start Learning
                            </a>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <div class="text-center py-12">
            <i class="fas fa-shopping-bag text-6xl text-gray-300 mb-4"></i>
            <h3 class="text-xl font-semibold text-gray-700 mb-2">No courses yet</h3>
            <p class="text-gray-500 mb-6">Start learning by purchasing a course</p>
            <a href="course.php" 
                class="inline-block bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition">
                Browse Courses
            </a>
        </div>
    <?php endif; ?>
</div>

<?php include 'common/bottom.php'; ?>
