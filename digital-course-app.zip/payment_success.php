<?php
require_once 'common/config.php';

if (!isUserLoggedIn()) {
    redirect('login.php');
}

$order_id = sanitize($_GET['order_id'] ?? '');

if (empty($order_id)) {
    redirect('index.php');
}

$user_id = $_SESSION['user_id'];

// Update purchase and payment status
mysqli_query($conn, "UPDATE purchases SET status = 'success' WHERE order_id = '$order_id' AND user_id = $user_id");
mysqli_query($conn, "UPDATE payments SET status = 'success' WHERE order_id = '$order_id' AND user_id = $user_id");

$page_title = 'Payment Success';
include 'common/header.php';
?>

<div class="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-green-50 to-green-100">
    <div class="bg-white rounded-lg shadow-lg p-8 max-w-md w-full text-center">
        <div class="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <i class="fas fa-check text-4xl text-white"></i>
        </div>
        
        <h1 class="text-2xl font-bold text-gray-800 mb-2">Payment Successful!</h1>
        <p class="text-gray-600 mb-6">Your course has been activated</p>
        
        <div class="bg-gray-50 rounded-lg p-4 mb-6">
            <p class="text-sm text-gray-600">Order ID</p>
            <p class="font-mono font-semibold text-gray-800"><?php echo htmlspecialchars($order_id); ?></p>
        </div>
        
        <div class="space-y-3">
            <a href="mycourses.php" 
                class="block w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition">
                Go to My Courses
            </a>
            <a href="index.php" 
                class="block w-full bg-gray-200 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-300 transition">
                Back to Home
            </a>
        </div>
    </div>
</div>

<?php include 'common/bottom.php'; ?>
