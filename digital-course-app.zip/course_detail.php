<?php
require_once 'common/config.php';

$course_id = intval($_GET['id'] ?? 0);

if ($course_id === 0) {
    redirect('course.php');
}

// Fetch course details
$course_query = "SELECT * FROM courses WHERE id = $course_id AND status = 1";
$course_result = mysqli_query($conn, $course_query);

if (mysqli_num_rows($course_result) === 0) {
    redirect('course.php');
}

$course = mysqli_fetch_assoc($course_result);

// Check if user has purchased
$is_purchased = false;
if (isUserLoggedIn()) {
    $user_id = $_SESSION['user_id'];
    $purchase_query = "SELECT id FROM purchases WHERE user_id = $user_id AND course_id = $course_id AND status = 'success'";
    $purchase_result = mysqli_query($conn, $purchase_query);
    $is_purchased = mysqli_num_rows($purchase_result) > 0;
}

$page_title = $course['title'];
$show_back = true;
include 'common/header.php';
?>

<!-- Course Thumbnail -->
<div class="relative">
    <img src="<?php echo htmlspecialchars($course['thumbnail']); ?>" 
        alt="<?php echo htmlspecialchars($course['title']); ?>" 
        class="w-full aspect-video object-cover">
    <?php if ($course['mrp'] > $course['price']): ?>
        <span class="absolute top-4 right-4 bg-green-500 text-white px-3 py-1 rounded-full font-semibold">
            <?php echo round((($course['mrp'] - $course['price']) / $course['mrp']) * 100); ?>% OFF
        </span>
    <?php endif; ?>
</div>

<!-- Course Details -->
<div class="bg-white p-4">
    <h1 class="text-2xl font-bold text-gray-800 mb-3">
        <?php echo htmlspecialchars($course['title']); ?>
    </h1>
    
    <div class="flex items-center space-x-3 mb-4">
        <span class="text-3xl font-bold text-blue-600">
            Rs <?php echo number_format($course['price'], 2); ?>
        </span>
        <?php if ($course['mrp'] > $course['price']): ?>
            <span class="text-lg text-gray-400 line-through">
                Rs <?php echo number_format($course['mrp'], 2); ?>
            </span>
        <?php endif; ?>
    </div>
    
    <?php if ($course['category']): ?>
        <div class="inline-block bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm mb-4">
            <?php echo htmlspecialchars($course['category']); ?>
        </div>
    <?php endif; ?>
    
    <hr class="my-4">
    
    <h3 class="text-lg font-semibold text-gray-800 mb-2">Course Description</h3>
    <div class="text-gray-600 leading-relaxed whitespace-pre-line">
        <?php echo nl2br(htmlspecialchars($course['description'])); ?>
    </div>
</div>

<!-- Sticky Buy Button -->
<div class="fixed bottom-0 left-0 right-0 bg-white border-t p-4 z-30" style="padding-bottom: calc(1rem + env(safe-area-inset-bottom));">
    <?php if (isUserLoggedIn()): ?>
        <?php if ($is_purchased): ?>
            <a href="watch.php?course_id=<?php echo $course_id; ?>" 
                class="block w-full bg-green-600 text-white py-4 rounded-lg font-semibold text-center hover:bg-green-700 transition">
                <i class="fas fa-play mr-2"></i> Start Learning
            </a>
        <?php else: ?>
            <a href="buy.php?course_id=<?php echo $course_id; ?>" 
                class="block w-full bg-blue-600 text-white py-4 rounded-lg font-semibold text-center hover:bg-blue-700 transition">
                <i class="fas fa-shopping-cart mr-2"></i> Buy Now - Rs <?php echo number_format($course['price'], 2); ?>
            </a>
        <?php endif; ?>
    <?php else: ?>
        <a href="login.php" 
            class="block w-full bg-blue-600 text-white py-4 rounded-lg font-semibold text-center hover:bg-blue-700 transition">
            Login to Purchase
        </a>
    <?php endif; ?>
</div>

<!-- Add bottom spacing for sticky button -->
<div class="h-24"></div>

<?php include 'common/bottom.php'; ?>
