# SkillzUp - Digital Course Selling Platform

A mobile-first digital course selling web application built with PHP, MySQL, Tailwind CSS, and JavaScript.

## Installation Instructions

1. **Prerequisites**
   - PHP 7.4 or higher
   - MySQL 5.7 or higher
   - Apache/Nginx web server
   - XAMPP/WAMP (for local development)

2. **Setup Steps**
   ```bash
   # 1. Extract the project to your web server directory
   # For XAMPP: C:/xampp/htdocs/skillzup
   # For WAMP: C:/wamp64/www/skillzup

   # 2. Create MySQL database
   # Open phpMyAdmin and create database named 'skillzup'

   # 3. Update database credentials if needed
   # Edit common/config.php and update:
   # - DB_HOST (default: 127.0.0.1)
   # - DB_USER (default: root)
   # - DB_PASS (default: root)
   # - DB_NAME (default: skillzup)

   # 4. Run installation
   # Visit: http://localhost/skillzup/install.php
   ```

3. **Default Credentials**
   - **Admin Panel**: http://localhost/skillzup/admin/
     - Username: `admin`
     - Password: `admin123`

4. **Create Required Folders**
   ```bash
   mkdir uploads
   mkdir uploads/banners
   mkdir uploads/courses
   mkdir uploads/videos
   chmod 777 uploads -R  # Linux/Mac only
   ```

5. **Security**
   - Delete `install.php` after installation
   - Change default admin password
   - Update Cashfree API credentials in admin settings

## Features

### User Panel
- User registration and login
- Browse and search courses
- Course details with preview
- Secure payment integration (Cashfree)
- My purchased courses
- Video player with download protection
- User profile management
- Help and support

### Admin Panel
- Dashboard with statistics
- Banner management
- Course management (CRUD)
- Chapter and video management
- User management
- Order tracking
- Payment history
- Settings configuration

## Technologies Used
- PHP (Backend)
- MySQL (Database)
- Tailwind CSS (Styling)
- JavaScript & AJAX (Frontend interactivity)
- Font Awesome (Icons)

## Security Features
- Password hashing (bcrypt)
- SQL injection prevention
- XSS protection
- CSRF protection
- Right-click disabled
- Text selection disabled
- Video download protection
- Secure file uploads

## Support
For issues or questions, contact: support@skillzup.com

## License
Proprietary - All rights reserved
