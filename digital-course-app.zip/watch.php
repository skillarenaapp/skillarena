<?php
require_once 'common/config.php';

// Check if user is logged in
if (!isUserLoggedIn()) {
    redirect('login.php');
}

$course_id = intval($_GET['course_id'] ?? 0);
$video_id = intval($_GET['video_id'] ?? 0);
$user_id = $_SESSION['user_id'];

if ($course_id === 0) {
    redirect('mycourses.php');
}

// Verify user has purchased the course
$purchase_check = "SELECT id FROM purchases WHERE user_id = $user_id AND course_id = $course_id AND status = 'success'";
$purchase_result = mysqli_query($conn, $purchase_check);

if (mysqli_num_rows($purchase_result) === 0) {
    redirect('course_detail.php?id=' . $course_id);
}

// Fetch course details
$course_query = "SELECT * FROM courses WHERE id = $course_id";
$course = mysqli_fetch_assoc(mysqli_query($conn, $course_query));

// Fetch chapters with videos
$chapters_query = "SELECT * FROM chapters WHERE course_id = $course_id ORDER BY sort_order ASC";
$chapters_result = mysqli_query($conn, $chapters_query);

// Get first video if none selected
if ($video_id === 0) {
    $first_video_query = "SELECT v.id FROM videos v 
                          INNER JOIN chapters c ON v.chapter_id = c.id 
                          WHERE c.course_id = $course_id 
                          ORDER BY c.sort_order ASC, v.sort_order ASC LIMIT 1";
    $first_video_result = mysqli_query($conn, $first_video_query);
    if (mysqli_num_rows($first_video_result) > 0) {
        $video_id = mysqli_fetch_assoc($first_video_result)['id'];
    }
}

// Fetch current video
$current_video = null;
if ($video_id > 0) {
    $video_query = "SELECT * FROM videos WHERE id = $video_id";
    $video_result = mysqli_query($conn, $video_query);
    if (mysqli_num_rows($video_result) > 0) {
        $current_video = mysqli_fetch_assoc($video_result);
    }
}

$page_title = $course['title'];
$show_back = true;
include 'common/header.php';
?>

<style>
    /* Custom video player controls */
    video {
        width: 100%;
        background: #000;
    }
    
    /* Hide download button in video controls */
    video::-internal-media-controls-download-button {
        display: none;
    }
    
    video::-webkit-media-controls-enclosure {
        overflow: hidden;
    }
    
    video::-webkit-media-controls-panel {
        width: calc(100% + 30px);
    }
    
    /* Accordion styles */
    .chapter-content {
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.3s ease;
    }
    
    .chapter-content.active {
        max-height: 1000px;
    }
</style>

<!-- Video Player -->
<div class="bg-black">
    <?php if ($current_video): ?>
        <video id="videoPlayer" 
            controls 
            controlsList="nodownload"
            oncontextmenu="return false;"
            class="w-full aspect-video">
            <source src="<?php echo htmlspecialchars($current_video['video_url']); ?>" type="video/mp4">
            Your browser does not support the video tag.
        </video>
    <?php else: ?>
        <div class="w-full aspect-video flex items-center justify-center text-white">
            <div class="text-center">
                <i class="fas fa-video-slash text-4xl mb-2"></i>
                <p>No video available</p>
            </div>
        </div>
    <?php endif; ?>
</div>

<!-- Video Info -->
<?php if ($current_video): ?>
<div class="bg-white p-4 border-b">
    <h2 class="text-lg font-bold text-gray-800"><?php echo htmlspecialchars($current_video['title']); ?></h2>
    <?php if ($current_video['duration']): ?>
        <p class="text-sm text-gray-500">
            <i class="fas fa-clock mr-1"></i> <?php echo htmlspecialchars($current_video['duration']); ?>
        </p>
    <?php endif; ?>
</div>
<?php endif; ?>

<!-- Course Content - Chapters & Videos -->
<div class="bg-white">
    <div class="p-4 border-b">
        <h3 class="text-lg font-semibold text-gray-800">Course Content</h3>
    </div>
    
    <div class="divide-y">
        <?php while ($chapter = mysqli_fetch_assoc($chapters_result)): ?>
            <?php
            $chapter_id = $chapter['id'];
            $videos_query = "SELECT * FROM videos WHERE chapter_id = $chapter_id ORDER BY sort_order ASC";
            $videos_result = mysqli_query($conn, $videos_query);
            $video_count = mysqli_num_rows($videos_result);
            ?>
            
            <div class="chapter-item">
                <button class="chapter-toggle w-full flex items-center justify-between p-4 hover:bg-gray-50 transition">
                    <div class="flex items-center space-x-3">
                        <i class="fas fa-folder text-blue-600"></i>
                        <div class="text-left">
                            <h4 class="font-semibold text-gray-800"><?php echo htmlspecialchars($chapter['title']); ?></h4>
                            <p class="text-sm text-gray-500"><?php echo $video_count; ?> videos</p>
                        </div>
                    </div>
                    <i class="fas fa-chevron-down text-gray-400 transition-transform"></i>
                </button>
                
                <div class="chapter-content bg-gray-50">
                    <?php while ($video = mysqli_fetch_assoc($videos_result)): ?>
                        <a href="watch.php?course_id=<?php echo $course_id; ?>&video_id=<?php echo $video['id']; ?>" 
                            class="flex items-center space-x-3 p-4 pl-12 hover:bg-white transition border-t <?php echo $video['id'] == $video_id ? 'bg-blue-50 border-l-4 border-l-blue-600' : ''; ?>">
                            <i class="fas fa-play-circle text-blue-600"></i>
                            <div class="flex-1">
                                <p class="font-medium text-gray-800 text-sm"><?php echo htmlspecialchars($video['title']); ?></p>
                                <?php if ($video['duration']): ?>
                                    <p class="text-xs text-gray-500"><?php echo htmlspecialchars($video['duration']); ?></p>
                                <?php endif; ?>
                            </div>
                        </a>
                    <?php endwhile; ?>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<!-- Bottom spacing -->
<div class="h-20"></div>

<script>
// Prevent right-click on video
const videoPlayer = document.getElementById('videoPlayer');
if (videoPlayer) {
    videoPlayer.addEventListener('contextmenu', function(e) {
        e.preventDefault();
        showToast('Download is not allowed', 'warning');
        return false;
    });
    
    // Prevent keyboard shortcuts for download
    videoPlayer.addEventListener('keydown', function(e) {
        if (e.ctrlKey && e.key === 's') {
            e.preventDefault();
            return false;
        }
    });
    
    // Disable picture-in-picture
    videoPlayer.disablePictureInPicture = true;
}

// Chapter accordion functionality
document.querySelectorAll('.chapter-toggle').forEach(button => {
    button.addEventListener('click', function() {
        const content = this.nextElementSibling;
        const icon = this.querySelector('.fa-chevron-down');
        
        // Close all other chapters
        document.querySelectorAll('.chapter-content').forEach(c => {
            if (c !== content) {
                c.classList.remove('active');
                c.previousElementSibling.querySelector('.fa-chevron-down').style.transform = 'rotate(0deg)';
            }
        });
        
        // Toggle current chapter
        content.classList.toggle('active');
        
        if (content.classList.contains('active')) {
            icon.style.transform = 'rotate(180deg)';
        } else {
            icon.style.transform = 'rotate(0deg)';
        }
    });
});

// Auto-open current video's chapter
document.addEventListener('DOMContentLoaded', function() {
    const activeVideo = document.querySelector('.border-l-blue-600');
    if (activeVideo) {
        const chapterContent = activeVideo.closest('.chapter-content');
        if (chapterContent) {
            chapterContent.classList.add('active');
            const icon = chapterContent.previousElementSibling.querySelector('.fa-chevron-down');
            if (icon) {
                icon.style.transform = 'rotate(180deg)';
            }
        }
    }
});
</script>

<?php include 'common/bottom.php'; ?>
